/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Jake
 */
public class ActiveEmployee 
{
    int employeeID;
    int locationID;
    String title;
    String firstName;
    String lastName;

    public ActiveEmployee( int iEmployeeID, int iLocationID, String sTitle, String sFirstName, String sLastName)
    {
        this.employeeID = iEmployeeID;
        this.locationID = iLocationID;
        this.title = sTitle;
        this.firstName = sFirstName;
        this.lastName = sLastName;
    }
    
}
