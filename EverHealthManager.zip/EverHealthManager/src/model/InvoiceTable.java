/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.text.NumberFormat;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.util.StringConverter;

/**
 *
 * @author jakew
 */
public class InvoiceTable 
{
    private final SimpleIntegerProperty rInvoiceID;
    private final SimpleStringProperty rDate;
    private final SimpleStringProperty rShipTo;
    private final SimpleStringProperty rBillTo;
    private final SimpleStringProperty rDescription;
    private final SimpleStringProperty rTotal;
    
    public InvoiceTable(int sInvoiceID, String sDate, String sShipTo, String sBillTo, String sDescription, double sTotal)
    {
        //capable to convert the double value to a String
        StringConverter<Double> converter = new StringConverter<Double>()
        {
            //adds the currency formatting
            NumberFormat formatter = NumberFormat.getCurrencyInstance();
            
            @Override
            public String toString(Double object) 
            {
                //adds the currency formatting
                String stringTotal =  formatter.format(object);
                return object == null ? "" : stringTotal ;
            }

            @Override
            public Double fromString(String string) 
            {
                return null;
            }
            
        };
        //does the conversion
        String stringTotal = converter.toString(sTotal);
        
        
        this.rInvoiceID = new SimpleIntegerProperty(sInvoiceID);
        this.rDate = new SimpleStringProperty(sDate);
        this.rShipTo = new SimpleStringProperty(sShipTo);
        this.rBillTo = new SimpleStringProperty(sBillTo);
        this.rDescription = new SimpleStringProperty(sDescription);
        this.rTotal = new SimpleStringProperty(stringTotal);
        
    }
    
    //Gets and Setts
    public Integer getRInvoiceID()
    {
        return rInvoiceID.get();
    }
    public void setRInvoiceID( Integer i)
    {
        rInvoiceID.set(i);
    }
    
    public String getRDate()
    {
        return rDate.get();
    }
    
    public void setRDate(String s)
    {
        rDate.set(s);
    }
    
    public String getRShipTo()
    {
        return rShipTo.get();
    }
    
    public void setRShipTo(String s)
    {
        rShipTo.set(s);
    }
    
    public String getRBillTo()
    {
        return rBillTo.get();
    }
    
    public void setRBillTo(String s)
    {
        rBillTo.set(s);
    }
    
    public String getRDescription()
    {
        return rDescription.get();
    }
    
    public void setRDescription(String s)
    {
        rDescription.set(s);
    }
    
    public String getRTotal()
    {
        return rTotal.get();
    }
    
    public void setRTotal(String s)
    {
        rTotal.set(s);
    }
}
