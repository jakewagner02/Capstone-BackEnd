/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Jake
 */
public class SearchedCustomer 
{
    private int customerID;
    private int locationID;
    private int membershipID;
    private int addressID;
    private String title;
    private String username;
    private String firstName;
    private String lastName;
    private String gender;
    private String phone;
    private String email;
    
    public SearchedCustomer(int iCustomerID, int iLocationID, int iMembershipID, int iAddressID, 
            String iTitle, String iUsername, String iFirstName, String iLastName, 
            String iGender, String iPhone, String iEmail)
    {
        customerID = iCustomerID;
        locationID = iLocationID;
        membershipID = iMembershipID;
        addressID = iAddressID;
        title = iTitle;
        username = iUsername;
        firstName = iFirstName;
        lastName = iLastName;
        gender = iGender;
        phone = iPhone;
        email = iEmail;
    }
    
    public int getCustomerID()
    {
        return customerID;
    }
    
    public int getLocationID()
    {
        return locationID;
    }
    
    public int getMembershipID()
    {
        return membershipID;
    }
    
    public int getAddressID()
    {
        return addressID;
    }
    
    public String getTitle()
    {
        return title;
    }
    
    public String getUsername()
    {
        return username;
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    
    public String getGender()
    {
        return gender;
    }
    
    public String getPhone()
    {
        return phone;
    }
    
    public String getEmail()
    {
        return email;
    }
    
}
