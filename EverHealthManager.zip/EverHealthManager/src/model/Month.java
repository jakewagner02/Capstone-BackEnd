/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 * Determines the month or the corresponding number 1-12
 * @author Jake
 */
public class Month 
{
    int monthInt;
    String monthName;
    
    public Month(int number)
    {
        monthInt = number;
    }
    public Month(String name)
    {
        monthName = name;
    }
    /**
     * Determines the ID of the gym
     * @return locationID
     */
    public String determineMonthInt()
    {
        String monthNumber = String.valueOf(monthInt);
        switch(monthName)
        {
            case "January":
                monthNumber = "01";
                break;
            case "February":
                monthNumber = "02";
                break; 
            case "March":
                monthNumber = "03";
                break;
            case "April":
                monthNumber = "04";
                break;
            case "May":
                monthNumber = "05";
                break;
            case "June":
                monthNumber = "06";
                break;
            case "July":
                monthNumber = "07";
                break;
            case "August":
                monthNumber = "08";
                break;
            case "September":
                monthNumber = "09";
                break;
            case "October":
                monthNumber = "10";
                break;
            case "November":
                monthNumber = "11";
                break;
            case "December":
                monthNumber = "12";
                break;
        }
                    
        return monthNumber;    
    }
    /**
     * Determines the city and state of the gym
     * @return locationPlace
     */
    public String determineMonthName()
    {
        switch(monthInt)
        {
            case 1:
                monthName ="January";                        
                break;
            case 2:
                monthName = "February";
                break;
            case 3:
                monthName = "March";
                break;
            case 4:
                monthName = "April";
                break;
            case 5:
                monthName = "May";
                break;
            case 6:
                monthName = "June";
                break;
            case 7:
                monthName = "July";
                break;
            case 8:
                monthName = "August";
                break;
            case 9:
                monthName = "September";
                break;
            case 10:
                monthName = "October";
                break;
            case 11:
                monthName = "November";
                break;
            case 12:
                monthName = "December";
                break;
        }   
        
        return monthName;
    }
}
