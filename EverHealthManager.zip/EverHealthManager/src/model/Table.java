/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Jake
 */
public class Table 
{
    private final SimpleIntegerProperty rID;
    private final SimpleStringProperty rUsername;
    private final SimpleStringProperty rFirstName;
    private final SimpleStringProperty rLastName;
    private final SimpleStringProperty rPhone;
    private final SimpleStringProperty rEmail;
    
    public Table(int sID, String sUsername, String sFirstName, String sLastName, String sPhone, String sEmail)
    {
        this.rID = new SimpleIntegerProperty(sID);
        this.rUsername = new SimpleStringProperty(sUsername);
        this.rFirstName = new SimpleStringProperty(sFirstName);
        this.rLastName = new SimpleStringProperty(sLastName);
        this.rPhone = new SimpleStringProperty(sPhone);
        this.rEmail = new SimpleStringProperty(sEmail);
        
    }
    //Gets and Setts
    public Integer getRID()
    {
        return rID.get();
    }
    public void setRID( Integer i)
    {
        rID.set(i);
    }
    
    public String getRUsername()
    {
        return rUsername.get();
    }
    
    public void setRUsername(String s)
    {
        rUsername.set(s);
    }
    
    public String getRFirstName()
    {
        return rFirstName.get();
    }
    
    public void setRFirstName(String s)
    {
        rFirstName.set(s);
    }
    
    public String getRLastName()
    {
        return rLastName.get();
    }
    
    public void setLastName(String s)
    {
        rLastName.set(s);
    }
    
    public String getRPhone()
    {
        return rPhone.get();
    }
    
    public void setRPhone(String s)
    {
        rPhone.set(s);
    }
    
    public String getREmail()
    {
        return rEmail.get();
    }
    
    public void setREmail(String s)
    {
        rEmail.set(s);
    }
}
