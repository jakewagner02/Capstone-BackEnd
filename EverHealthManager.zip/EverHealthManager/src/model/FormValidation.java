/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author Jake
 */
public class FormValidation 
{
    //makes sure a text field is not empty or null
    public static boolean textFieldNotEmpty(TextField t)
    {
        boolean value =  false;
        
        if(t.getText() != null && !t.getText().isEmpty())
        {
            value = true;
        }
        return value;
    }
    public static boolean textFieldNotEmpty(TextField t, Label l, String sValidationText)
    {
        boolean value = true;
        String c = null;
        if(!textFieldNotEmpty(t))
        {
            value = false;
            c = sValidationText;
        }
        l.setText(c);
        return value;
    }
    
    //makes sure the text field only submits numbers
    public static boolean textFieldTypeNumber(TextField t)
    {
        boolean value = false;
        if(t.getText().matches("[0-9]+"))
        {
            value = true;
        }
        return value;
    }
    public static boolean textFieldTypeNumber(TextField t, Label l, String sValidationText)
    {
        boolean value = true;
        String c = null;
        if(!textFieldTypeNumber(t))
        {
            value = false;
            c = sValidationText;
        }
        l.setText(c);
        return value;
    }
    
    //makes sure a text Area is not empty or null
    public static boolean textAreaNotEmpty(TextArea t)
    {
        boolean value =  false;
        
        if(t.getText() != null && !t.getText().isEmpty())
        {
            value = true;
        }
        return value;
    }
    public static boolean textAreaNotEmpty(TextArea t, Label l, String sValidationText)
    {
        boolean value = true;
        String c = null;
        if(!textAreaNotEmpty(t))
        {
            value = false;
            c = sValidationText;
        }
        l.setText(c);
        return value;
    }
    
    //makes sure a choice box is not empty or null
    public static boolean choiceBoxNotEmpty(ChoiceBox c)
    {
        boolean value =  false;
        
        if(c.getValue() != null && !c.getValue().toString().isEmpty())
        {
            value = true;
        }
        return value;
    }
    public static boolean choiceBoxNotEmpty(ChoiceBox c, Label l, String sValidationText)
    {
        boolean value = true;
        String d = null;
        if(!choiceBoxNotEmpty(c))
        {
            value = false;
            d = sValidationText;
        }
        l.setText(d);
        return value;
    }
    
    //makes sure a combo box is not empty or null
    public static boolean comboBoxNotEmpty(ComboBox c)
    {
        boolean value =  false;
        
        if(c.getValue() != null && !c.getValue().toString().isEmpty())
        {
            value = true;
        }
        return value;
    }
    public static boolean comboBoxNotEmpty(ComboBox c, Label l, String sValidationText)
    {
        boolean value = true;
        String d = null;
        if(!comboBoxNotEmpty(c))
        {
            value = false;
            d = sValidationText;
        }
        l.setText(d);
        return value;
    }
    //makes sure a date picker is not empty or null
    public static boolean datePickerNotEmpty(DatePicker d)
    {
        boolean value =  false;
        
        if(d.getValue() != null && !d.getValue().toString().isEmpty())
        {
            value = true;
        }
        return value;
    }
    public static boolean datePickerNotEmpty(DatePicker d, Label l, String sValidationText)
    {
        boolean value = true;
        String s = null;
        if(!datePickerNotEmpty(d))
        {
            value = false;
            s = sValidationText;
        }
        l.setText(s);
        return value;
        
    }
    //makes sure a password field is not empty or null
    public static boolean passwordFieldNotEmpty(PasswordField p)
    {
        boolean value =  false;
        
        if(p.getText() != null && !p.getText().isEmpty())
        {
            value = true;
        }
        return value;
    }
    public static boolean passwordFieldNotEmpty(PasswordField p, Label l, String sValidationText)
    {
        boolean value = true;
        String c = null;
        if(!passwordFieldNotEmpty(p))
        {
            value = false;
            c = sValidationText;
        }
        l.setText(c);
        return value;
    }
    
    
    public static void addLiveValidation(TextField t,String regex, Label v, Label mainVal, String message)
    {
        t.focusedProperty().addListener((listener, oldVal, newVal)->
        {
            if(!newVal)
            {
                if(!t.getText().matches(regex))
                {
                    t.setText("");
                    t.setPromptText("Invalid");
                    v.setText("*");
                    mainVal.setText(message);
                }
                else
                {
                    v.setText("");
                    t.setPromptText("");
                    mainVal.setText("");
                }
            }
        });
        
    }
    public static void addLiveValidation(TextArea t,String regex, Label v, Label mainVal, String message)
    {
        t.focusedProperty().addListener((listener, oldVal, newVal)->
        {
            if(!newVal)
            {
                if(!t.getText().matches(regex))
                {
                    t.setText("");
                    t.setPromptText("Invalid");
                    v.setText("");
                    mainVal.setText(message);
                }
                else
                {
                    v.setText("");
                    t.setPromptText("");
                    mainVal.setText("");
                }
            }
        });
    }
    public static void addLiveValidation(MaskField t,String regex, Label v, Label mainVal, String message, String emptyMask, String newMask)
    {
        t.focusedProperty().addListener((listener, oldVal, newVal)->
        {
            if(!newVal)
            {
                if(!t.getText().matches(regex))
                {
                    t.setMask(emptyMask);
                    t.setMask(newMask);
                    
                    v.setText("*");
                    mainVal.setText(message);
                }
                else
                {
                    v.setText("");
                    t.setPromptText("");
                    mainVal.setText("");
                }
            }
        });
    }
    
     
    
    
}
