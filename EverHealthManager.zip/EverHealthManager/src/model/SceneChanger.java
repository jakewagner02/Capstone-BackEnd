/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author Jake
 */
public  abstract class SceneChanger 
{
    /**
     * responsible for loading and switching to the new scene
     * @param page String, name of the scene to switch to
     * @param e the event
     * @throws IOException if page not found
     */
    public void changeScene(String page, ActionEvent e) throws IOException
    {
        Parent home_page_parent = FXMLLoader.load(getClass().getResource(page));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        app_stage.getIcons().add(new Image("/images/everhealth-logo.png"));
        app_stage.hide();
        app_stage.setScene(home_page_scene);
        app_stage.show();
    }
    
    //Doesnt hide the current scene
    public void openScene(String page) throws IOException
    {
     Parent home_page_parent = FXMLLoader.load(getClass().getResource(page));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage stage = new Stage();
        stage.setScene(home_page_scene);
        stage.show();   
    }
    
}
