/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;



/**
 * Connector class to a sql Database
 * @author Jacob Wagner
 */
public class SqlConnection 
{

 /**
  * attempts to connect to the database and returns null if not
  * @return conn database connection
  */
 public static Connection DBconnect()
 {
     try
     {
    	 Connection conn = null;
    	 conn = DriverManager.getConnection("jdbc:mysql://54.164.39.175:3306/everhealth", "jake" , "cscccapstone"); 
    	 return conn;
     }catch(Exception e)
     {
         return null;
     }
 }
}
