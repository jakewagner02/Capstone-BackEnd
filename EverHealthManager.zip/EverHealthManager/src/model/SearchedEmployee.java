/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author jakew
 */
public class SearchedEmployee 
{
    int employeeID;
    String userName;
    int locationID;
    String title;
    String firstName;
    String lastName;
    String birthDate;
    String gender;
    String hireDate;
    String socialSecurity;
    
    public SearchedEmployee( int iEmployeeID, String iUserName, int iLocationID, String iTitle, String iFirstName, String iLastName, String iBirthDate, String iGender, String iHireDate, String iSocialSecurity)
    {
        employeeID = iEmployeeID;
        userName = iUserName;
        locationID = iLocationID;
        title = iTitle;
        firstName = iFirstName;
        lastName = iLastName;
        birthDate = iBirthDate;
        gender = iGender;
        hireDate = iHireDate;
        socialSecurity = iSocialSecurity;
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public String getUserName() {
        return userName;
    }

    public int getLocationID() {
        return locationID;
    }

    public String getTitle() {
        return title;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public String getGender() {
        return gender;
    }

    public String getHireDate() {
        return hireDate;
    }

    public String getSocialSecurity() {
        return socialSecurity;
    }
    
    
    
    
}
