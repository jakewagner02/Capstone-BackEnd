/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author jakew
 */
public class ItemTable 
{
    private final SimpleIntegerProperty rInventoryID;
    private final SimpleStringProperty rLocation;
    private final SimpleIntegerProperty rInvoiceID;
    private final SimpleStringProperty rItemName;
    private final SimpleStringProperty rModelNo;
    private final SimpleStringProperty rCondition;
    
    public ItemTable(int sIventoryID, String sLocation, int sInvoiceID, String sItemName, String sModelNo, String sCondition)
    {
        this.rInventoryID = new SimpleIntegerProperty(sIventoryID);
        this.rLocation = new SimpleStringProperty(sLocation);
        this.rInvoiceID = new SimpleIntegerProperty(sInvoiceID);
        this.rItemName = new SimpleStringProperty(sItemName);
        this.rModelNo = new SimpleStringProperty(sModelNo);
        this.rCondition = new SimpleStringProperty(sCondition);
        
    }
    
    //Gets and Setts
    public Integer getRInventoryID()
    {
        return rInventoryID.get();
    }
    public void setRInventoryID( Integer i)
    {
        rInventoryID.set(i);
    }
    
    public String getRLocation()
    {
        return rLocation.get();
    }
    
    public void setRLocation(String s)
    {
        rLocation.set(s);
    }
    
    public int getRInvoiceID()
    {
        return rInvoiceID.get();
    }
    
    public void setRInvoiceID(int s)
    {
        rInvoiceID.set(s);
    }
    
    public String getRItemName()
    {
        return rItemName.get();
    }
    
    public void setRItemName(String s)
    {
        rItemName.set(s);
    }
    
    public String getRModelNo()
    {
        return rModelNo.get();
    }
    
    public void setRModelNo(String s)
    {
        rModelNo.set(s);
    }
    
    public String getRCondition()
    {
        return rCondition.get();
    }
    
    public void setRCondition(String s)
    {
        rCondition.set(s);
    }
    
}
