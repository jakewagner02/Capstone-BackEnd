/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 * The location of a gym
 * @author jakew
 */
public class Location 
{
    int locationID;
    String locationPlace;
    
    public Location(int ID)
    {
        locationID = ID;
    }
    public Location(String place)
    {
        locationPlace = place;
    }
    /**
     * Determines the ID of the gym
     * @return locationID
     */
    public int determineLocationID()
    {
        switch(locationPlace)
                {
                    case "Tucson, AZ": 
                        locationID = 11;
                        break;
                    case "Los Angeles, CA":
                        locationID = 13;
                        break;
                    case "San Francisco, CA":
                        locationID = 14;
                        break;
                    case "Denver, CO":
                        locationID = 15;
                        break;
                    case "Chicago, IL":
                        locationID = 8;
                        break;
                    case "Detroit, MI":
                        locationID = 5;
                        break;
                    case "Albuquerque, NM":
                        locationID = 12;
                        break;
                    case "Cincinnati, OH":
                        locationID = 4;
                        break;
                    case "Columbus, OH":
                        locationID = 6;
                        break;
                    case "Philadelphia, PA":
                        locationID = 1;
                        break;
                    case "Dallas, TX":
                        locationID = 9;
                        break;
                    case "Houston, TX":
                        locationID = 10;
                        break;
                    case "Arlington, VA":
                        locationID = 3;
                        break;
                    case "Milwaukee, WI": 
                        locationID = 7;
                        break;
                }
        return locationID;
    }
    /**
     * Determines the city and state of the gym
     * @return locationPlace
     */
    public String determinePlace()
    {
        switch(locationID)
                {
                    case 11:
                        locationPlace ="Tucson, AZ";                        
                        break;
                    case 13:
                        locationPlace = "Los Angeles, CA";
                        break;
                    case 14:
                        locationPlace = "San Francisco, CA";
                        break;
                    case 15:
                        locationPlace = "Denver, CO";
                        break;
                    case 8:
                        locationPlace = "Chicago, IL";
                        break;
                    case 5:
                        locationPlace = "Detroit, MI";
                        break;
                    case 12:
                        locationPlace = "Albuquerque, NM";
                        break;
                    case 4:
                        locationPlace = "Cincinnati, OH";
                        break;
                    case 6:
                        locationPlace = "Columbus, OH";
                        break;
                    case 1:
                        locationPlace = "Philadelphia, PA";
                        break;
                    case 9:
                        locationPlace = "Dallas, TX";
                        break;
                    case 10:
                        locationPlace = "Houston, TX";
                        break;
                    case 3:
                        locationPlace = "Arlington, VA";
                        break;
                    case 7: 
                        locationPlace = "Milwaukee, WI";
                        break;
                } 
        return locationPlace;
    }
            
}
