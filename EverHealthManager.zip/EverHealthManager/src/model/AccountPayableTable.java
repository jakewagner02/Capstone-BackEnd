/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.text.NumberFormat;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.util.StringConverter;

/**
 *
 * @author jakew
 */
public class AccountPayableTable 
{
    private final SimpleIntegerProperty rPayableID;
    private final SimpleIntegerProperty rInvoiceID;
    private final SimpleStringProperty rName;
    private final SimpleStringProperty rDescription;
    private final SimpleStringProperty rCredit;
    private final SimpleStringProperty rDebit;
    private final SimpleStringProperty rDatePayable;
    
    public AccountPayableTable(int sPayableID, int sInvoiceID, String sName, String sDescription, double sCredit, double sDebit, String sDatePayable)
    {
        //capable to convert the double value to a String
        StringConverter<Double> converter = new StringConverter<Double>()
        {
            //adds the currency formatting
            NumberFormat formatter = NumberFormat.getCurrencyInstance();
            
            @Override
            public String toString(Double object) 
            {
                //adds the currency formatting
                String stringTotal =  formatter.format(object);
                return object == null ? "" : stringTotal ;
            }

            @Override
            public Double fromString(String string) 
            {
                return null;
            }
            
        };
        //does the conversion
        String stringCredit = converter.toString(sCredit);
        String stringDebit = converter.toString(sDebit);
        
        
        this.rPayableID = new SimpleIntegerProperty(sPayableID);
        this.rInvoiceID = new SimpleIntegerProperty(sInvoiceID);
        this.rName = new SimpleStringProperty(sName);
        this.rDescription = new SimpleStringProperty(sDescription);
        this.rCredit = new SimpleStringProperty(stringCredit);
        this.rDebit = new SimpleStringProperty(stringDebit);
        this.rDatePayable = new SimpleStringProperty(sDatePayable);
        
    }
    
    //Gets and Setts
    public Integer getRPayableID()
    {
        return rPayableID.get();
    }
    public void setRPayableID( Integer i)
    {
        rPayableID.set(i);
    }
    
    public Integer getRInvoiceID()
    {
        return rInvoiceID.get();
    }
    public void setRInvoiceID( Integer i)
    {
        rInvoiceID.set(i);
    }
    
    public String getRName()
    {
        return rName.get();
    }
    
    public void setRName(String s)
    {
        rName.set(s);
    }
    
    public String getRDescription()
    {
        return rDescription.get();
    }
    
    public void setRDescription(String s)
    {
        rDescription.set(s);
    }
    
    public String getRCredit()
    {
        return rCredit.get();
    }
    
    public void setRCredit(String s)
    {
        rCredit.set(s);
    }
    
    public String getRDebit()
    {
        return rDebit.get();
    }
    
    public void setRDebit(String s)
    {
        rDebit.set(s);
    }
    
    public String getRDatePayable()
    {
        return rDatePayable.get();
    }
    
    public void setRDatePayable(String s)
    {
        rDatePayable.set(s);
    }
}
