/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author jakew
 */
public class SearchedItem 
{
    private int invID;
    private int locationID;
    private int invoiceID;
    private String itemName;
    private String modelNo;
    private String dop;
    private String itemCond;
    private String note;
    

    public SearchedItem(int iInvID, int iLocationID, int iInvoiceID, String iItemName, String iModelNo, String iDop, String iItemCond, String iNote)
    {
        invID = iInvID;
        locationID = iLocationID;
        invoiceID = iInvoiceID;
        itemName = iItemName;
        modelNo = iModelNo;
        dop = iDop;
        itemCond = iItemCond;
        note = iNote;
    }
    
    public int getInventoryID()
    {
        return invID;
    }
    public int getLocationID()
    {
        return locationID;
    }
    public int getInvoiceID()
    {
        return invoiceID;
    }
    public String getItemName()
    {
        return itemName;
    }
    public String getModelNo()
    {
        return modelNo;
    }
    public String getDateOfPurchase()
    {
        return dop;
    }
    public String getNote()
    {
        return note;
    }
}
