/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import everhealthmanager.EmployeeInventoryController;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import model.FormValidation;
import model.Location;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class AddItemTabController implements Initializable 
{
    //hold reference to the inventory main controller
    private EmployeeInventoryController invController;
    
    //FXML tags
    @FXML private TextField itemInvoiceAddField;
    @FXML private TextField itemNameAddField;
    @FXML private TextField itemModelNoAddField;
    @FXML private ChoiceBox itemLocationAddChoiceBox;
    @FXML private ChoiceBox itemConditionAddChoiceBox;
    @FXML private TextArea itemNoteTextArea;
    @FXML private DatePicker itemPurchaseDatePicker;
    
    //validation labels
    @FXML private Label itemInvoiceAddVal;
    @FXML private Label nameAddVal;
    @FXML private Label modelNoAddVal;
    @FXML private Label itemLocationAddVal;
    @FXML private Label conditionAddVal;
    @FXML private Label dopVal;
    @FXML private Label validationLabel;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // populate choiceBoxes
        itemLocationAddChoiceBox.setItems(FXCollections.observableArrayList("Tucson, AZ" , "Los Angeles, CA" , "San Francisco, CA" , "Denver, CO" ,
                                                                     "Chicago, IL" , "Detroit, MI" , "Albuquerque, NM" , "Cincinnati, OH" , "Columbus, OH" ,
                                                                     "Philadelphia, PA" , "Dallas, TX" , "Houston, TX" , "Arlington, VA" , "Milwaukee, WI"));
        itemConditionAddChoiceBox.setItems(FXCollections.observableArrayList("new", "excellent", "very good", "good","fair","bad","needs-replaced"));
        
        //individual validation
        FormValidation.addLiveValidation(itemInvoiceAddField, "^[0-9]{1,11}|$", itemInvoiceAddVal, validationLabel, "Invoice must be numeric\n must be 11 digits or less");
        FormValidation.addLiveValidation(itemNameAddField, "^[A-Za-z0-9 ]{1,30}|$", nameAddVal, validationLabel, "Name must be alphanumeric\n must be 30 characters or less");
        FormValidation.addLiveValidation(itemModelNoAddField, "^[0-9]{1,11}|$", modelNoAddVal, validationLabel, "Model No. must be numeric\n must be 11 digits or less");
        FormValidation.addLiveValidation(itemNoteTextArea, "^.{1,240}|$", itemInvoiceAddVal, validationLabel, "Note is too long");
        
        
    }    

    public void init(EmployeeInventoryController employeeInventoryController) 
    {
         invController = employeeInventoryController;
    }
    
    @FXML
    public void handleAddItemButton(ActionEvent event)
    {
                     
        //Form Validation
        boolean itemInvoice = FormValidation.textFieldNotEmpty(itemInvoiceAddField, itemInvoiceAddVal, "*field required");
        boolean itemName = FormValidation.textFieldNotEmpty(itemNameAddField, nameAddVal, "*field required");
        boolean modelNo = FormValidation.textFieldNotEmpty(itemModelNoAddField, modelNoAddVal, "*field required");
        boolean purchaseDate = FormValidation.datePickerNotEmpty(itemPurchaseDatePicker, dopVal, "*pick a date");
        boolean itemLocation = FormValidation.choiceBoxNotEmpty(itemLocationAddChoiceBox, itemLocationAddVal, "*field required");
        boolean itemCondition = FormValidation.choiceBoxNotEmpty(itemConditionAddChoiceBox, conditionAddVal, "*field required");
        
        if(itemInvoice && itemName && modelNo && purchaseDate && itemLocation && itemCondition)
        {
            System.out.println("The Add item button works!");
            addItem();
        }
    }
    
    @FXML
    private void handleClearItemButton(ActionEvent ev)
    {
        itemInvoiceAddField.clear();
        itemNameAddField.clear();
        itemModelNoAddField.clear();
        itemPurchaseDatePicker.setValue(null);
        itemLocationAddChoiceBox.setValue(null);
        itemConditionAddChoiceBox.setValue(null);
        itemNoteTextArea.clear();
        itemInvoiceAddField.setPromptText("");
        itemNameAddField.setPromptText("");
        itemModelNoAddField.setPromptText("");
        itemNoteTextArea.setPromptText("");
        itemInvoiceAddField.requestFocus();
        itemInvoiceAddVal.setText("");
        nameAddVal.setText("");
        modelNoAddVal.setText("");
        dopVal.setText("");
        itemLocationAddVal.setText("");
        conditionAddVal.setText(""); 
        itemNoteTextArea.setPromptText("");
    }
    /**
     * connects to the database
     * builds the query
     * adds the item to the database
     */
    private void addItem()
    {
        String query = ""; //holds the query
        try
        {
            //Connect to the database
            Connection conn = SqlConnection.DBconnect();
            java.sql.Statement stmt = conn.createStatement();
            
            //get the locationID
            Location itemLocation = new Location(itemLocationAddChoiceBox.getValue().toString());
            
            //build the query
            query = "INSERT INTO inventory(location_ID, invoice_ID, item_name, model_no, date_of_purchase, item_condition, note) VALUES " +
                    "(" + itemLocation.determineLocationID() + ", " + itemInvoiceAddField.getText() + ", '" + itemNameAddField.getText() + "', '" +
                    itemModelNoAddField.getText() + "', '" + itemPurchaseDatePicker.getValue() + "', '" + itemConditionAddChoiceBox.getValue().toString() + 
                    "', '" + itemNoteTextArea.getText() + "')";
            
            System.out.println(query);
            
            //make sure the invoice exists
            //make sure the invoice ID is in the database
            ResultSet invoiceRS = stmt.executeQuery("SELECT * FROM invoices WHERE invoice_ID = " + itemInvoiceAddField.getText());
            if(invoiceRS.next())
            {
                //execute the query
                stmt.executeUpdate(query);
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText(null);
                alert.setContentText("" + itemNameAddField.getText() + " was successfully added");

                alert.showAndWait();
            }
            else //present a warning
            {
                Alert wrongID = new Alert(AlertType.INFORMATION);
                wrongID.setTitle("No Invoice");
                wrongID.setHeaderText(null);
                wrongID.setContentText("There is no invoice with that number");

                wrongID.showAndWait();
            }
            //close the connections
            invoiceRS.close();
            stmt.close();
            conn.close();
            
        }
        catch(SQLException e)
        {
            System.out.println("Failed to add item to the inventory");
            e.printStackTrace();
        }
        
    }
    
}
