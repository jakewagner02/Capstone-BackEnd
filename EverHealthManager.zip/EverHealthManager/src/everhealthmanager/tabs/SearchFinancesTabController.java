/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.InvoiceTable;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class SearchFinancesTabController implements Initializable 
{
    //holds reference to the Finances main page
    
    //Holds the instance of the searched invoice
    
    //FXML Tags
    @FXML private TextField invoiceIDSearchField;
    
    //Define invoice Search Table
    @FXML 
    private TableView<InvoiceTable> financeSearchTable;
    @FXML 
    private TableColumn<InvoiceTable, Integer> iInvoiceID;
    @FXML 
    private TableColumn<InvoiceTable, String> iDate;
    @FXML
    private TableColumn<InvoiceTable, Integer> iBillTo;
    @FXML 
    private TableColumn<InvoiceTable, String> iShipTo;
    @FXML 
    private TableColumn<InvoiceTable, String> iDescription;
    @FXML 
    private TableColumn<InvoiceTable, Double> iTotal;
    
    //Create table data
    final ObservableList<InvoiceTable> financeData = FXCollections.observableArrayList();
    
    @FXML
    private void handleSearchInvoiceButton(ActionEvent e)
    {
        searchInvoice();
    }
    
    @FXML
    /**
     * prints the tableview
     */
    private void handlePrintButton(ActionEvent e)
    {
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        PrinterJob job = PrinterJob.createPrinterJob();
        //if there is no data in the table do not print
        if(!financeData.isEmpty())
        {
            if (job != null) 
            {                    
                boolean showDialog = job.showPageSetupDialog(app_stage);
                if (showDialog) 
                {                        
                    financeSearchTable.setScaleX(0.50);
                    financeSearchTable.setScaleY(0.50);
                    financeSearchTable.setTranslateX(-200);
                    financeSearchTable.setTranslateY(-50);
                }
                boolean success = job.printPage(financeSearchTable);
                if (success) 
                {
                             job.endJob(); 
                } 
                financeSearchTable.setTranslateX(0);
                financeSearchTable.setTranslateY(0);               
                financeSearchTable.setScaleX(1.0);
                financeSearchTable.setScaleY(1.0);                                              
            }
        }
        else
        {
            Alert noData = new Alert(Alert.AlertType.WARNING);
                   noData.setTitle("Print Job Cancelled");
                   noData.setHeaderText(null);
                   noData.setContentText("There is no information to print");
                   noData.showAndWait();
        }
       
        
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //initialize the item table
        iInvoiceID.setCellValueFactory(new PropertyValueFactory<InvoiceTable, Integer>("rInvoiceID"));
        iDate.setCellValueFactory(new PropertyValueFactory<InvoiceTable, String>("rDate"));
        iBillTo.setCellValueFactory(new PropertyValueFactory<InvoiceTable, Integer>("rBillTo"));
        iShipTo.setCellValueFactory(new PropertyValueFactory<InvoiceTable, String>("rShipTo"));
        iDescription.setCellValueFactory(new PropertyValueFactory<InvoiceTable, String>("rDescription"));
        iTotal.setCellValueFactory(new PropertyValueFactory<InvoiceTable, Double>("rTotal"));
        
        financeSearchTable.setItems(financeData);
        
        //live validation
        invoiceIDSearchField.focusedProperty().addListener((listener, oldVal, newVal)->
        {
            if(!newVal)
            {
                if(!invoiceIDSearchField.getText().matches("^[0-9]{0,11}|$"))
                {
                   invoiceIDSearchField.setText("");
                   invoiceIDSearchField.setPromptText("Enter Numbers Only");
                   
                }
                else
                {
                    invoiceIDSearchField.setPromptText("");                   
                }
            }
        });
    } 
    
    private void searchInvoice()
    {
        //clear any data in the table
        financeData.clear();
        System.out.println("You clicked the invoice search button"); //test
        
        //Simplified Validation
        //If invoice field is empty, display an error   
        if(invoiceIDSearchField.getText().isEmpty())
        {
            Alert noInput = new Alert(Alert.AlertType.WARNING);
                   noInput.setTitle("Warning");
                   noInput.setHeaderText(null);
                   noInput.setContentText("Please enter an invoice ID");
                   noInput.showAndWait();
        }
        else
        {
            //connect to the database and search
            try
            {
                Connection conn = SqlConnection.DBconnect();
                conn.setAutoCommit(false);
                java.sql.Statement stmt = conn.createStatement();
                String query = "SELECT invoices.invoice_ID, invoices.invoice_date, invoices.bill_to, invoices.ship_to, detail.description, detail.total FROM invoices INNER JOIN detail on invoices.detail_ID = detail.detail_ID WHERE invoices.invoice_ID = '" + invoiceIDSearchField.getText() + "'";
                
                ResultSet invoiceRS = stmt.executeQuery(query);
                
                boolean empty = true; // true if no results are found in the database

                //    
                while(invoiceRS.next())
                {
                    InvoiceTable entry = new InvoiceTable(invoiceRS.getInt("invoice_ID"), invoiceRS.getString("invoice_date"), invoiceRS.getString("ship_to"), invoiceRS.getString("bill_to"),invoiceRS.getString("description"), invoiceRS.getDouble("total"));
                    financeData.add(entry);

                   
                
                    empty = false; //false if there is data in the Result Set
                }
                
                //if there is no data display a message
                if(empty == true)
                {
                    Alert emptyAlert = new Alert(Alert.AlertType.INFORMATION);
                    emptyAlert.setTitle("NO INFORMATION FOUND");
                    emptyAlert.setHeaderText("No Invoice with that information");
                    emptyAlert.showAndWait();
                }
                //close the connections
                invoiceRS.close();
                stmt.close();
                conn.close();
            }
            catch(SQLException e)
            {
                System.out.println("Failed to search the finances table");
                e.printStackTrace();
            }

        }
    }
    @FXML 
    private void handleClearButton(ActionEvent event)
    {
        invoiceIDSearchField.clear();
        invoiceIDSearchField.setPromptText("");
        financeData.clear();
    }
    
}
