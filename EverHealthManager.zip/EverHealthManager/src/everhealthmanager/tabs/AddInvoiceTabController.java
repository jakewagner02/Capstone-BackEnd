/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import com.mysql.jdbc.Statement;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import model.FormValidation;
import model.FxUtilTest;
import model.MaskField;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class AddInvoiceTabController implements Initializable 
{
    //FXML tags
    @FXML private TextField billNameField;
    @FXML private TextField billAddressField;
    @FXML private TextField billCityField;
    @FXML private MaskField billZipField;
    @FXML private TextField shipNameField;
    @FXML private TextField shipAddressField;
    @FXML private TextField shipCityField;
    @FXML private MaskField shipZipField;
    @FXML private TextField SKUField;
    @FXML private TextField quantityField;
    @FXML private TextArea descriptionArea;
    @FXML private TextField costField;
    @FXML private TextField totalField;
    
    @FXML private Label billNameVal;
    @FXML private Label billAddressVal;
    @FXML private Label billCityVal;
    @FXML private Label billStateVal;
    @FXML private Label billZipVal;
    @FXML private Label shipNameVal;
    @FXML private Label shipAddressVal;
    @FXML private Label shipCityVal;
    @FXML private Label shipStateVal;
    @FXML private Label shipZipVal;
    @FXML private Label SKUVal;
    @FXML private Label quantityVal;
    @FXML private Label descriptionVal;  
    @FXML private Label costVal;
    @FXML private Label validationLabel;
    
    @FXML ComboBox billStateBox;
    @FXML ComboBox shipStateBox;
    
    /**
     * Adds the invoice to the database
     */
    private void addInvoice()
    {
        //get todays date
         java.sql.Date today = new java.sql.Date(new java.util.Date().getTime());
         System.out.println("this is the date: " +  today);
        
        String invoiceDetailQuery = "INSERT INTO detail (sku, description, price, quantity, total) VALUES("; //Holds the beginnings of a insert query
        String invoiceQuery = "INSERT INTO invoices (detail_ID, invoice_date, bill_to, billing_address, billing_city, billing_state, billing_zip, ship_to, ship_to_address, ship_to_city, ship_to_state, ship_to_zip) VALUES("; //Holds the beginnings of a insert query
        
        //append to the detail string
        String invoiceDetailBuilder = "'" + SKUField.getText() + "', '" + descriptionArea.getText() + "', '" + costField.getText().replaceAll("[$ ]","") + "', '" + quantityField.getText() + "', '" + totalField.getText().replaceAll("[$ ]","") + "')";
        invoiceDetailQuery = invoiceDetailQuery + invoiceDetailBuilder;
        System.out.println(invoiceDetailQuery);
        
        
        
        //connect to the database
        try
        {
            Connection conn = SqlConnection.DBconnect();
            java.sql.Statement  stmt = conn.createStatement();
            stmt.executeUpdate(invoiceDetailQuery, Statement.RETURN_GENERATED_KEYS);
            ResultSet detKey = stmt.getGeneratedKeys();
            if(detKey.next())
            {
                int newDetID = detKey.getInt(1); //the generated detail ID
                System.out.println(newDetID);
                
                //append to the invoice string
                String invoiceQueryBuilder = "'" + newDetID + "', '" + today + "', '" + billNameField.getText() + "', '" + billAddressField.getText() + "', '" + billCityField.getText() + "', '" + 
                                            billStateBox.getValue().toString() + "', '" + billZipField.getText() + "', '" + shipNameField.getText() + "', '" + shipAddressField.getText()
                                             + "', '" + shipCityField.getText() + "', '" + shipStateBox.getValue().toString() + "', '" + shipZipField.getText() + "')"; 
                invoiceQuery = invoiceQuery + invoiceQueryBuilder;
                System.out.println(invoiceQuery);
                
                stmt.executeUpdate(invoiceQuery);
                
                //if the information was added successfully show an alert
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText("Invoice was successfully added");
                alert.setContentText("SKU " + SKUField.getText() + " was added to the database");
                alert.showAndWait();
        
            }
            //close the conenctions
            detKey.close();
            stmt.close();
            conn.close();
        }
        catch(SQLException e)
        {
            System.out.println("Failed to add invoice to the database");
            e.printStackTrace();
        }
    }
    
    @FXML
    /**
     * handles blank validation
     */
    private void handleInvoiceSubmitButton(ActionEvent event)
    {
        //Validation
        boolean billName = FormValidation.textFieldNotEmpty(billNameField, billNameVal, "*");
        boolean billAddress = FormValidation.textFieldNotEmpty(billAddressField, billAddressVal, "*");
        boolean billCity = FormValidation.textFieldNotEmpty(billCityField, billCityVal, "*");
        boolean billZip = FormValidation.textFieldNotEmpty(billZipField, billZipVal, "*");
        boolean billState = FormValidation.comboBoxNotEmpty(billStateBox, billStateVal, "*");
        boolean shipName = FormValidation.textFieldNotEmpty(shipNameField, shipNameVal, "*");
        boolean shipAddress = FormValidation.textFieldNotEmpty(shipAddressField, shipAddressVal, "*");
        boolean shipCity = FormValidation.textFieldNotEmpty(shipCityField, shipCityVal, "*");
        boolean shipZip = FormValidation.textFieldNotEmpty(shipZipField, shipZipVal, "*");
        boolean shipState = FormValidation.comboBoxNotEmpty(shipStateBox, shipStateVal, "*");        
        boolean sku = FormValidation.textFieldNotEmpty(SKUField, SKUVal, "*");
        boolean quantity = FormValidation.textFieldNotEmpty(quantityField, quantityVal, "*");
        boolean description = FormValidation.textAreaNotEmpty(descriptionArea, descriptionVal, "*");
        boolean cost = FormValidation.textFieldNotEmpty(costField, costVal, "*");
        
        
        if(billName && billAddress && billCity && !billZipField.getText().equals("_____") && billState && shipName && shipAddress && shipCity && !shipZipField.getText().equals("_____") && shipState && sku && quantity && description && cost)
        {
            addInvoice();
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
                 
        //prepare the choiceboxes
        ObservableList<String> states = FXCollections.observableArrayList("AK","AL","AR","AZ","CA","CO","CT","DC","DE","FL",
                "GA","GU","HI","IA","ID", "IL","IN","KS","KY","LA",
                "MA","MD","ME","MH","MI","MN","MO","MS","MT","NC",
                "ND","NE","NH","NJ","NM","NV","NY", "OH","OK","OR",
                "PA","PR","PW","RI","SC","SD","TN","TX","UT","VA",
                "VI","VT","WA","WI","WV","WY");
        billStateBox.setItems(states);
        shipStateBox.setItems(states);
        
        //makes the state combo box autocomplete        
        FxUtilTest.autoCompleteComboBoxPlus(billStateBox, (typedText, itemToCompare) -> itemToCompare.toString().toUpperCase().startsWith(typedText.toUpperCase()));      
     
        FxUtilTest.autoCompleteComboBoxPlus(shipStateBox, (typedText, itemToCompare) -> itemToCompare.toString().toUpperCase().startsWith(typedText.toUpperCase()));      

        
        //add a change listeners to calculate the total of the values in the cost and quantity field
        costField.focusedProperty().addListener((listener, oldVal, newVal)->
        {
            
            if(!newVal)
            {
                if(!costField.getText().matches("^([0-9]{1,30})|([0-9]{0,30}[.]{1}[0-9]{2})|[.]{1}[0-9]{2}"))
                {
                    costField.setText("");
                    costField.setPromptText("Invalid");
                    costVal.setText("*");
                    validationLabel.setText("Enter a monetary value");
                }
                else
                {
                    Double creditDouble = Double.parseDouble(costField.getText());
                    DecimalFormat formatter = new DecimalFormat( "$ ###,###,###.00" );
                    String creditString = formatter.format(creditDouble);
                    costField.setText(creditString);
                    
                    //calculates the total field
                    if(!quantityField.getText().isEmpty())
                    {
                        Double totalCost = creditDouble * Double.parseDouble(quantityField.getText());
                        String totalString = formatter.format(totalCost);
                        System.out.println(totalString);
                        totalField.setText(totalString);
                    }
                }
            }
            else
            {
                if(!costField.getText().matches("^([0-9]{1,20})|([0-9]{0,20}[.]{1}[0-9]{2})|[.]{1}[0-9]{2}"))
                {
                    costField.setText("");
                }    
            }
               
        });
        
        
        //add live validation
        FormValidation.addLiveValidation(billNameField, "(?:[a-zA-Z ]{0,50}|)", billNameVal, validationLabel, "Name must be letters only\n must be under 50 characters");
        FormValidation.addLiveValidation(billAddressField, "(?:[a-zA-Z0-9 ]{0,50}|)", billAddressVal, validationLabel, "Address must be alphanumeric\n must be under 50 characters");
        FormValidation.addLiveValidation(billCityField, "(?:[a-zA-Z]{0,30}|)", billCityVal, validationLabel, "City must be letters only\n must be under 30 characters");
        FormValidation.addLiveValidation(shipNameField, "(?:[a-zA-Z]{0,50}|)", shipNameVal, validationLabel, "Name must be letters only\nmust be under 50 characters");
        FormValidation.addLiveValidation(shipAddressField, "(?:[a-zA-Z0-9 ]{0,50}|)", shipAddressVal, validationLabel, "Address must be alphanumeric\n must be under 50 characters");
        FormValidation.addLiveValidation(shipCityField, "(?:[a-zA-Z]{0,30}|)", shipCityVal, validationLabel, "City must be letters only\n must be under 30 characters");
        FormValidation.addLiveValidation(billZipField, "^[0-9]{5}|$", billZipVal, validationLabel,"Zip must contain 5 digits", "_____", "DDDDD");
        FormValidation.addLiveValidation(shipZipField, "^[0-9]{5}|$", shipZipVal, validationLabel,"Zip must contain 5 digits", "_____", "DDDDD");
        FormValidation.addLiveValidation(SKUField, "(?:[0-9]{1,30}|)", SKUVal, validationLabel, "SKU must be digits only\n must be under 30 characters");
        FormValidation.addLiveValidation(quantityField, "(?:[0-9]{1,11}|)", quantityVal, validationLabel, "Quantity must be digits only\n must be 11 characters or less");
        
        

    }
    
    @FXML 
    /**
     * clears all the fields and resets the focus
     */
    private void handleClearButton()
    {
        billNameField.clear();
        billAddressField.clear();
        billCityField.clear();
        shipNameField.clear();
        shipAddressField.clear();
        shipCityField.clear();
        billNameField.clear();
        billAddressField.setPromptText("");
        billCityField.setPromptText("");
        shipNameField.setPromptText("");
        shipAddressField.setPromptText("");
        shipCityField.setPromptText("");
        shipStateVal.setText("");
        billZipField.setMask("_____");
        billZipField.setMask("DDDDD");
        shipZipField.setMask("_____");
        shipZipField.setMask("DDDDD");
        SKUField.clear();
        quantityField.clear();
        costField.clear();
        totalField.clear();
        descriptionArea.clear();
        SKUField.setPromptText("");
        quantityField.setPromptText("");
        costField.setPromptText("");
        totalField.setPromptText("");
        descriptionArea.setPromptText("");
        billNameVal.setText("");
        billAddressVal.setText("");
        billCityVal.setText("");
        billStateVal.setText("");
        shipNameVal.setText("");
        shipAddressVal.setText("");
        shipCityVal.setText("");
        billZipVal.setText("");
        shipZipVal.setText("");
        SKUVal.setText("");
        quantityVal.setText("");
        costVal.setText("");
        descriptionVal.setText("");
        billStateBox.setValue(null);
        shipStateBox.setValue(null);
        validationLabel.setText("");
        billNameField.requestFocus();
                
        
    }
}
