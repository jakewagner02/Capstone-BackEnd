/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import everhealthmanager.EmployeeCustomerController;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.MaskField;
import model.SceneChanger;
import model.SearchedCustomer;
import model.SqlConnection;
import model.Table;

/**
 * FXML Controller class
 *
 * @author Jake
 */
public class SearchCustomerTabController extends SceneChanger implements Initializable 
{
    private EmployeeCustomerController custController;
    
    //Holds the instance of the searched customer
    public SearchedCustomer currentCustomer = null;
    
    //FXML tags for search customer tab
    @FXML
    private TextField firstNameSearchField;
    @FXML 
    private TextField lastNameSearchField;
    @FXML
    private MaskField phoneSearchField;
    @FXML
    private TextField emailSearchField;
    @FXML
    private TextField customerIDSearchField;
    @FXML 
    private TextField usernameSearchField;
    
    //Define Customer Search Table
    @FXML 
    private TableView<Table> tableID;
    @FXML 
    private TableColumn<Table, Integer> iID;
    @FXML 
    private TableColumn<Table, String> iUsername;
    @FXML
    private TableColumn<Table, String> iFirstName;
    @FXML 
    private TableColumn<Table, String> iLastName;
    @FXML 
    private TableColumn<Table, String> iPhone;
    @FXML 
    private TableColumn<Table, String> iEmail;
    
    
    //Create table data
    final ObservableList<Table> data = FXCollections.observableArrayList();
    
    @FXML
    private void handleClearSearchButtonAction(ActionEvent event)
    {
       customerIDSearchField.clear();
       usernameSearchField.clear();
       firstNameSearchField.clear();
       lastNameSearchField.clear();
       phoneSearchField.setMask("(___)___-____");
       phoneSearchField.setMask("(DDD)DDD-DDDD");
       emailSearchField.clear();
       data.clear();
       customerIDSearchField.requestFocus();
    }
    
    @FXML
    /**
     * handles when the customer search button is pressed
     */
    private void handleSearchButton(ActionEvent event)
    {
        searchDatabase();
    }

    /**
     * Initializes the controller class.
     * Initializes table tableID
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
       iID.setCellValueFactory(new PropertyValueFactory<>("rID"));
       iUsername.setCellValueFactory(new PropertyValueFactory<>("rUsername"));
       iFirstName.setCellValueFactory(new PropertyValueFactory<>("rFirstName"));
       iLastName.setCellValueFactory(new PropertyValueFactory<>("rLastName"));
       iPhone.setCellValueFactory(new PropertyValueFactory<>("rPhone"));
       iEmail.setCellValueFactory(new PropertyValueFactory<>("rEmail"));
        
       tableID.setItems(data);
       
       //this is the live validation
       phoneSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!phoneSearchField.getText().matches("^[0-9()]{8}[-]{1}[0-9]{4}"))
                       {
                       
                           phoneSearchField.setMask("(___)___-____");
                           phoneSearchField.setMask("(DDD)DDD-DDDD");
                           
                       }
                       
                   }
               });
       customerIDSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!customerIDSearchField.getText().matches("^|[0-9]{1,11}$"))
                       {
                       
                           customerIDSearchField.setText("");
                           customerIDSearchField.setPromptText("Enter a Valid Number");
                       }
                       else
                       {
                           customerIDSearchField.setPromptText("");
                       }
                   }
               });
       usernameSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!usernameSearchField.getText().matches("^[A-Za-z0-9]{1,20}|$"))
                       {
                       
                           usernameSearchField.setText("");
                           usernameSearchField.setPromptText("Enter a Valid Username");
                       }
                       else
                       {
                           usernameSearchField.setPromptText("");
                       }
                   }
               });
       firstNameSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!firstNameSearchField.getText().matches("^[A-Za-z]{1,20}|$"))
                       {
                       
                           firstNameSearchField.setText("");
                           firstNameSearchField.setPromptText("Enter Valid Letters");
                       }
                       else
                       {
                           firstNameSearchField.setPromptText("");
                       }
                   }
               });
       lastNameSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!lastNameSearchField.getText().matches("^[A-Za-z]{1,20}|$"))
                       {
                       
                           lastNameSearchField.setText("");
                           lastNameSearchField.setPromptText("Enter Valid Letters");
                       }
                       else
                       {
                           lastNameSearchField.setPromptText("");
                       }
                   }
               });
       emailSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!emailSearchField.getText().matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])|"))
                       {
                       
                           emailSearchField.setText("");
                           emailSearchField.setPromptText("Enter a Valid E-mail");                   
                       }
                       else
                       {
                           emailSearchField.setPromptText("");
                       }
                   }
               });
       
    }    
    
    /**
     * Connects to the Database, builds query based on the information input, and outputs it to an alert box
     */
    private void searchDatabase()
    {
        String query = "SELECT * FROM customer WHERE " ;
        
        //Clear any information in the table
        data.clear();
        
        //Simplified Validation
            //If all search fields are empty, display an error   
        if(customerIDSearchField.getText().isEmpty() && usernameSearchField.getText().isEmpty() 
           && firstNameSearchField.getText().isEmpty() && lastNameSearchField.getText().isEmpty() 
           && phoneSearchField.getText().equals("(___)___-____") && emailSearchField.getText().isEmpty())
               {
                   Alert noInput = new Alert(Alert.AlertType.WARNING);
                   noInput.setTitle("Warning");
                   noInput.setHeaderText(null);
                   noInput.setContentText("Please enter data");
                   noInput.showAndWait();
               }
        else
        {
            //connect to the database and search
            try
            {
                Connection conn = SqlConnection.DBconnect();
                conn.setAutoCommit(false);
                java.sql.Statement stmt = conn.createStatement();

                //logic for appending statements
                if(!customerIDSearchField.getText().isEmpty())
                {
                   String customerString = "customer_ID LIKE " + "'" + customerIDSearchField.getText() + "%'";
                   query = query + customerString;
                   //checks to add AND statements if any other textfield has data
                   if(!usernameSearchField.getText().isEmpty() || !firstNameSearchField.getText().isEmpty() || !lastNameSearchField.getText().isEmpty() || !phoneSearchField.getText().equals("(___)___-____") || !emailSearchField.getText().isEmpty())
                   {
                       query = query + " AND ";
                   }
                }

                if(!usernameSearchField.getText().isEmpty())
                {
                   String usernameString = "account_username LIKE " + "'" + usernameSearchField.getText() + "%'";
                   query = query + usernameString;

                   if(!firstNameSearchField.getText().isEmpty() || !lastNameSearchField.getText().isEmpty() || !phoneSearchField.getText().equals("(___)___-____") || !emailSearchField.getText().isEmpty())
                   {
                       query = query + " AND ";
                   }

                }
                if(!firstNameSearchField.getText().isEmpty())
                {
                   String firstNameString = "first_name LIKE " + "'" + firstNameSearchField.getText() + "%'";
                   query = query + firstNameString;

                   if(!lastNameSearchField.getText().isEmpty() || !phoneSearchField.getText().equals("(___)___-____") || !emailSearchField.getText().isEmpty())
                   {
                       query = query + " AND ";
                   }

                }
                if(!lastNameSearchField.getText().isEmpty())
                {
                   String lastNameString = "last_name LIKE " + "'" + lastNameSearchField.getText() + "%'";
                   query = query + lastNameString;

                   if(!phoneSearchField.getText().equals("(___)___-____") || !emailSearchField.getText().isEmpty())
                   {
                       query = query + " AND ";
                   }

                }
                if(!phoneSearchField.getText().equals("(___)___-____"))
                {
                   String phoneString = "phone= " + "'" + phoneSearchField.getText() + "'";
                   query = query + phoneString;

                   if(!emailSearchField.getText().isEmpty())
                   {
                       query = query + " AND ";
                   }

                }
                if(!emailSearchField.getText().isEmpty())
                {
                   String phoneString = "email= " + "'" + emailSearchField.getText() + "'";
                   query = query + phoneString;


                }

                System.out.println(query);


                //Process the results into the table
                ResultSet rs = stmt.executeQuery(query);
                boolean empty = true; // true if no results are found in the database

                //    
                while(rs.next())
                {
                    Table entry = new Table(rs.getInt("customer_ID"), rs.getString("account_username"), rs.getString("first_name"), rs.getString("last_name"),rs.getString("phone"), rs.getString("email"));
                    data.add(entry);

                   
                
                    empty = false; //false if there is data in the Result Set
                }
                
                //if there is no data display a message
                if(empty == true)
                {
                    Alert emptyAlert = new Alert(Alert.AlertType.INFORMATION);
                    emptyAlert.setTitle("NO INFORMATION FOUND");
                    emptyAlert.setHeaderText("No customer with that information");
                    emptyAlert.showAndWait();
                }
                //close the connections
                rs.close();
                stmt.close();
                conn.close();
            }
            catch(SQLException e)
            {
                System.out.println("There is a problem in searchDatabase");
                e.printStackTrace();
            }
        }
            
    }
    
    @FXML
    /**
     * handles when a row is double clicked
     * 
     */
    private void handleRowSelection(MouseEvent event) throws IOException
    {
        if(event.isPrimaryButtonDown() && event.getClickCount() == 2)
        {
            try 
            {               
                //uses the username of the double clicked row to populate a searchedCustomer
                Table userSearch = tableID.getSelectionModel().getSelectedItem();
                System.out.println(userSearch.getRUsername());
                
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("Select * FROM customer WHERE account_username = '" + userSearch.getRUsername() + "'");
                
                
                while(rs.next())
                {
                   currentCustomer = new SearchedCustomer(rs.getInt("customer_ID"), rs.getInt("location_ID"), rs.getInt("membership_ID"), rs.getInt("address_ID"), rs.getString("title"), rs.getString("account_username"), rs.getString("first_name"), rs.getString("last_name"),rs.getString("gender"), rs.getString("phone"), rs.getString("email"));
                   System.out.println(currentCustomer.getUsername() + currentCustomer.getLocationID() + currentCustomer.getMembershipID());
                }
                
                //creates a pop up window with various options
                Alert options = new Alert(AlertType.CONFIRMATION);
                options.setTitle("SELECTED USER: " +currentCustomer.getUsername());
                options.setHeaderText(null);
                options.setContentText("Select an option: ");
                // Add a custom icon
                Stage stage = (Stage) options.getDialogPane().getScene().getWindow();
                stage.getIcons().add(new Image(this.getClass().getResource("/images/everhealth-logo.png").toString()));
                
                ButtonType editButton = new ButtonType("Edit");
                ButtonType endMembButton = new ButtonType("End Membership");
                ButtonType cancelButton = new ButtonType ("Cancel", ButtonData.CANCEL_CLOSE);
                
                options.getButtonTypes().setAll(editButton, endMembButton, cancelButton);
                Optional <ButtonType> result = options.showAndWait();
                
                //opens a new window or closes
                if(result.get() == editButton)
                {
                    custController.setMainCustomer();
                    custController.editCustomer.setDisable(false);
                    custController.searchCustomer.setDisable(true);
                    custController.addCustomer.setDisable(true);
                    custController.customerTabPane.getSelectionModel().select(custController.editCustomer); 
                    
                    
                }
                if(result.get() == endMembButton)
                {   
                    //this alert box confirmst the cancel
                    Alert alert = new Alert(AlertType.CONFIRMATION);
                    alert.setTitle("Confirm Cancellation ");
                    alert.setHeaderText("Are you sure?");
                    alert.setContentText("Cancel " + currentCustomer.getUsername() + "?");

                    Optional<ButtonType> cancelResult = alert.showAndWait();
                    if (cancelResult.get() == ButtonType.OK)
                    {
                        //changes the value of the plan to canceled
                        stmt.executeUpdate("UPDATE membership SET plan = 'canceled' WHERE membership_ID = '" + currentCustomer.getMembershipID() + "'");
                        System.out.println(stmt);
                        //shows the success alert box
                        Alert success = new Alert(AlertType.INFORMATION);
                        success.setTitle("Cancel Complete");
                        success.setHeaderText(null);
                        success.setContentText(currentCustomer.getUsername() + "'s plan was successfully cancelled.");

                        success.showAndWait();
                    } 
                    else 
                    {
                        // ... user chose CANCEL or closed the dialog
                    }    
                        
                    
                }
                else
                {
                    //User choice cancel
                }
                //close the connections
                rs.close();
                stmt.close();
                conn.close();
            } 
            catch (SQLException ex) 
            {
                Logger.getLogger(SearchCustomerTabController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            
            
           
                    
        }
        
    }

    public void init(EmployeeCustomerController employeeCustomerController)
    {
        custController = employeeCustomerController;
    }
    
    public SearchedCustomer getCustomer()
    {
        return currentCustomer;
    }
    
      
    
    
}
