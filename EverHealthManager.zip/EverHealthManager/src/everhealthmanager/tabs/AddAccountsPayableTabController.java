/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import model.FormValidation;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class AddAccountsPayableTabController implements Initializable 
{
    //FXML tags for add customer tab
    @FXML TextField APNameField;
    @FXML TextField APInvoiceNoField;
    @FXML TextArea APDescriptionArea;
    @FXML TextField APCreditField;
    @FXML TextField APDebitField;
    
    @FXML Label APNameVal;
    @FXML Label APInvoiceVal;
    @FXML Label APDescriptionVal;
    @FXML Label APCreditVal;
    @FXML Label APDebitVal;
    @FXML Label APDateVal;
    @FXML Label validationLabel;
    
    @FXML DatePicker APDatePicker;
    
    private void addInvoice()
    {
       //get the doubles out of the credit and debit fields
       String creditStr = APCreditField.getText().replaceAll("[$ ]",""); //holds the value of the double
       String debitStr = APDebitField.getText().replaceAll("[$ ]","");  //holds the value of the double  
       String accountQuery = "INSERT INTO accounts_payable (invoice_ID, name, description, credit, debit, payable_date) VALUES("; //Holds the beginnings of a search query
       String accountBuilder = "'" + APInvoiceNoField.getText() + "', '" + APNameField.getText() + "', '" + APDescriptionArea.getText() + "', '" + 
                                     creditStr + "', '" + debitStr + "', '" + APDatePicker.getValue().toString() + "')";
       accountQuery = accountQuery + accountBuilder;
       System.out.println(accountQuery); //test
       
       //connect and perform the sql statements
       try
       {
            //connect to the database and create statement
            Connection conn = SqlConnection.DBconnect();
            java.sql.Statement stmt = conn.createStatement(); 
            //make sure the invoice exists
            ResultSet invoiceRS = stmt.executeQuery("SELECT * FROM invoices WHERE invoice_ID = " + APInvoiceNoField.getText());
            if(!invoiceRS.next())
            {
                Alert wrongID = new Alert(AlertType.INFORMATION);
                wrongID.setTitle("No Invoice");
                wrongID.setHeaderText(null);
                wrongID.setContentText("There is no invoice with that number");

                wrongID.showAndWait();
            }
            else// add the account payable
            {
                stmt.executeUpdate(accountQuery);

                //Alert notifying that the account was added
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText("Account Payable was successfully added");
                alert.setContentText(APNameField.getText() + " was added to the database");

                alert.showAndWait();
            }
            //close the connections
            invoiceRS.close();
            stmt.close();
            conn.close();

       }
       catch(SQLException e)
       {
           System.out.println("Failed to add the new acct payable");
           e.printStackTrace();
       }
       
    }
    
    @FXML
    private void handleAccountPayableSubmitButton(ActionEvent event)
    {        
        //Form Validation
        boolean name = FormValidation.textFieldNotEmpty(APNameField, APNameVal, "*");
        boolean invoice = FormValidation.textFieldNotEmpty(APInvoiceNoField, APInvoiceVal, "*");
        boolean description = FormValidation.textAreaNotEmpty(APDescriptionArea, APDescriptionVal, "*");
        boolean credit = FormValidation.textFieldNotEmpty(APCreditField, APCreditVal, "*");
        boolean debit = FormValidation.textFieldNotEmpty(APDebitField, APDebitVal, "*");
        boolean date = FormValidation.datePickerNotEmpty(APDatePicker, APDateVal, "*");

        if(name && invoice && description && credit && debit && date)
        {
            addInvoice();
        }
    }
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
       //live validation
       //add action listeners for live validation
        FormValidation.addLiveValidation(APNameField, "^[A-Za-z0-9 ]{0,20}|$", APNameVal, validationLabel, "Account name must be alphanumeric\n must be 20 characters or less");
        FormValidation.addLiveValidation(APInvoiceNoField, "^(?:[0-9]{0,11})|", APInvoiceVal, validationLabel, "Invoice must be numeric\n must be 11 characters or less");
        FormValidation.addLiveValidation(APDescriptionArea, "^.{1,140}|", APInvoiceVal, validationLabel, "Description is too long");
        
        APCreditField.focusedProperty().addListener((listener, oldVal, newVal)->
        {
            
            if(!newVal)
            {
                if(!APCreditField.getText().matches("^([0-9]{1,30})|([0-9]{0,30}[.]{1}[0-9]{2})|[.]{1}[0-9]{2}"))
                {
                    APCreditField.setText("");
                    APCreditField.setPromptText("Invalid");
                    APCreditVal.setText("*");
                    validationLabel.setText("Enter a monetary value");
                }
                else
                {
                    Double creditDouble = Double.parseDouble(APCreditField.getText());
                    DecimalFormat format = new DecimalFormat( "$ ###,###.00" );
                    String creditString = format.format(creditDouble);
                    APCreditField.setText(creditString);
                }
            }
            else
            {
                if(!APCreditField.getText().matches("^([0-9]{1,20})|([0-9]{0,20}[.]{1}[0-9]{2})|[.]{1}[0-9]{2}"))
                {
                    APCreditField.setText("");
                }    
            }
               
        });
        
        APDebitField.focusedProperty().addListener((listener, oldVal, newVal)->
        {
            
            if(!newVal)
            {
                if(!APDebitField.getText().matches("^([0-9]{1,20})|([0-9]{0,20}[.]{1}[0-9]{2})|[.]{1}[0-9]{2}"))
                {
                    APDebitField.setText("");
                    APDebitField.setPromptText("Invalid");
                    APDebitVal.setText("*");
                    validationLabel.setText("Enter a monetary value");
                }
                else
                {
                    Double creditDouble = Double.parseDouble(APDebitField.getText());
                    DecimalFormat format = new DecimalFormat( "$ ###,###,###,###.00" );
                    String creditString = format.format(creditDouble);
                    APDebitField.setText(creditString);
                }
            }
            else
            {
                if(!APDebitField.getText().matches("^([0-9]{1,20})|([0-9]{0,20}[.]{1}[0-9]{2})|[.]{1}[0-9]{2}"))
                {
                    APDebitField.setText("");
                }    
            }
               
        });
                
        
    }
    
    @FXML
    private void handleClearButton(ActionEvent event)
    {
        APNameField.clear();
        APInvoiceNoField.clear();
        APDescriptionArea.clear();
        APCreditField.clear();
        APDebitField.clear();
        APDatePicker.setValue(null);
        APNameVal.setText("");
        APInvoiceVal.setText("");
        APDescriptionVal.setText("");
        APCreditVal.setText("");
        APDebitVal.setText("");
        APDateVal.setText("");
        APNameField.setPromptText("");
        APInvoiceNoField.setPromptText("");
        APDescriptionArea.setPromptText("");
        APCreditField.setPromptText("");
        APDebitField.setPromptText("");
        APDatePicker.setPromptText("");
        validationLabel.setText("");
        APNameField.requestFocus();
        
        
        
    }
        
    
}
