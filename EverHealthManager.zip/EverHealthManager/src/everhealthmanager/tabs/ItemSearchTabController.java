/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import everhealthmanager.EmployeeInventoryController;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import model.ItemTable;
import model.Location;
import model.SearchedItem;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class ItemSearchTabController implements Initializable 
{
    //holds reference to the Employee Inventory main page
    private EmployeeInventoryController invController;
    
    //Holds the instance of the searched item
    private SearchedItem currentItem;
    
    
    //FXML Tags
    @FXML private TextField inventoryIDSearchField;
    @FXML private TextField invoiceIDSearchField;
    @FXML private TextField itemNameSearchField;
    @FXML private TextField modelNoSearchField;
    
    @FXML private ChoiceBox conditionSearchBox;
    @FXML private ChoiceBox locationSearchBox;
    
    
    
        
    
    //Define Customer Search Table
    @FXML 
    private TableView<ItemTable> itemSearchTable;
    @FXML 
    private TableColumn<ItemTable, Integer> iInventoryID;
    @FXML 
    private TableColumn<ItemTable, String> iLocation;
    @FXML
    private TableColumn<ItemTable, Integer> iInvoiceID;
    @FXML 
    private TableColumn<ItemTable, String> iItemName;
    @FXML 
    private TableColumn<ItemTable, String> iModelNo;
    @FXML 
    private TableColumn<ItemTable, String> iCondition;
    
    //Create table data
    final ObservableList<ItemTable> itemData = FXCollections.observableArrayList();
    
    
    @FXML
    private void handleItemClearButton()
    {
        inventoryIDSearchField.clear();
        locationSearchBox.setValue(null);
        invoiceIDSearchField.clear();
        itemNameSearchField.clear();
        modelNoSearchField.clear();
        conditionSearchBox.setValue(null);
        
        itemData.clear();
        inventoryIDSearchField.requestFocus();
        
    }
    
    @FXML
    /**
     * performs a search when the search item button is clicked
     */
    private void handleItemSearchButton(ActionEvent event)
    {
        searchItemDatabase();
    }
    
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //initialize the item table
        iInventoryID.setCellValueFactory(new PropertyValueFactory<ItemTable, Integer>("rInventoryID"));
        iLocation.setCellValueFactory(new PropertyValueFactory<ItemTable, String>("rLocation"));
        iInvoiceID.setCellValueFactory(new PropertyValueFactory<ItemTable, Integer>("rInvoiceID"));
        iItemName.setCellValueFactory(new PropertyValueFactory<ItemTable, String>("rItemName"));
        iModelNo.setCellValueFactory(new PropertyValueFactory<ItemTable, String>("rModelNo"));
        iCondition.setCellValueFactory(new PropertyValueFactory<ItemTable, String>("rCondition"));
        
        itemSearchTable.setItems(itemData);
        
        //load items into the location search box
        locationSearchBox.setItems(FXCollections.observableArrayList("Tucson, AZ" , "Los Angeles, CA" , "San Francisco, CA" , "Denver, CO" ,
                                   "Chicago, IL" , "Detroit, MI" , "Albuquerque, NM" , "Cincinnati, OH" , "Columbus, OH" ,
                                   "Philadelphia, PA" , "Dallas, TX" , "Houston, TX" , "Arlington, VA" , "Milwaukee, WI"));
        //load items into the condition search box
        conditionSearchBox.setItems(FXCollections.observableArrayList("new", "excellent", "very good", "good","fair","bad","needs-replaced"));
        
        //individual validation
        inventoryIDSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!inventoryIDSearchField.getText().matches("^[0-9]{1,11}|$"))
                       {
                       
                           inventoryIDSearchField.setText("");
                           inventoryIDSearchField.setPromptText("Enter a Valid Number");
                       }
                       else
                       {
                           inventoryIDSearchField.setPromptText("");
                       }
                   }
               });
        invoiceIDSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!invoiceIDSearchField.getText().matches("^[0-9]{1,11}|$"))
                       {
                       
                           invoiceIDSearchField.setText("");
                           invoiceIDSearchField.setPromptText("Enter a Valid Number");
                       }
                       else
                       {
                           invoiceIDSearchField.setPromptText("");
                       }
                   }
               });
        modelNoSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!modelNoSearchField.getText().matches("^[0-9]{1,11}|$"))
                       {
                       
                           modelNoSearchField.setText("");
                           modelNoSearchField.setPromptText("Enter a Valid Number");
                       }
                       else
                       {
                           modelNoSearchField.setPromptText("");
                       }
                   }
               });
        itemNameSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!itemNameSearchField.getText().matches("^[A-Za-z0-9 ]{1,30}|$"))
                       {
                       
                           itemNameSearchField.setText("");
                           itemNameSearchField.setPromptText("Enter a Valid Name");
                       }
                       else
                       {
                           itemNameSearchField.setPromptText("");
                       }
                   }
               });
        
    }    

    public void init(EmployeeInventoryController employeeInventoryController) 
    {
       invController = employeeInventoryController; 
    }
    
    /**
     * Searches the database for the item
     */
    private void searchItemDatabase()
    {
        System.out.println("You clicked the item search button"); //test
        
        //the rebuildable query based on the selected searchfields
        String searchQuery = "SELECT * FROM inventory WHERE " ;
        
        //Clear any information in the table
        itemData.clear();
        
        //Simplified Validation
        //If all search fields are empty, display an error   
        if(inventoryIDSearchField.getText().isEmpty() && locationSearchBox.getValue() == null
           && invoiceIDSearchField.getText().isEmpty() && itemNameSearchField.getText().isEmpty() 
           && modelNoSearchField.getText().isEmpty() && conditionSearchBox.getValue() == null)
        {
            Alert noInput = new Alert(Alert.AlertType.WARNING);
                   noInput.setTitle("Warning");
                   noInput.setHeaderText(null);
                   noInput.setContentText("Please enter data");
                   noInput.showAndWait();
        }
        else //perform the action
        {                  
            System.out.println("Got past the validation");            
            
             try
            {
                //Connect to the database
                Connection conn = SqlConnection.DBconnect();                
                java.sql.Statement stmt = conn.createStatement();
                
                //begin logic for appending statements to inventory query
                //if the inventory search field is not empty, add the information to the query
                if(!inventoryIDSearchField.getText().isEmpty())
                {
               
                    String invIDString = "inventory_ID LIKE " + "'" + inventoryIDSearchField.getText() + "%'";
                    searchQuery = searchQuery + invIDString;
                    //checks to add AND statements if any other textfield has data
                    if(locationSearchBox.getValue() != null || !invoiceIDSearchField.getText().isEmpty() || !itemNameSearchField.getText().isEmpty() || !modelNoSearchField.getText().isEmpty() || conditionSearchBox.getValue() != null)
                    {
                       searchQuery = searchQuery + " AND ";
                    }
                    
                }
                
                //if the location search box is not empty, use the value to get the ID and add it to the query
                if(locationSearchBox.getValue() != null)
                {                   
                       //creates a new location object based on the value
                       Location itemLocation = new Location(locationSearchBox.getValue().toString());
                       String locationString = "location_ID= " + "'" + itemLocation.determineLocationID() + "'";
                       searchQuery = searchQuery + locationString;
                       //checks to add AND statements if any other textfield has data
                       if(!invoiceIDSearchField.getText().isEmpty() || !itemNameSearchField.getText().isEmpty() || !modelNoSearchField.getText().isEmpty() || conditionSearchBox.getValue() != null)
                       {
                          searchQuery = searchQuery + " AND ";
                       }
                    
                   
                }
                
                //if the invoicesearch box is not empty, add data to query
                if(!invoiceIDSearchField.getText().isEmpty())
                {
                
                    String invoiceString = "invoice_ID LIKE " + "'" + invoiceIDSearchField.getText() + "%'";
                    searchQuery = searchQuery + invoiceString;
                    //checks to add AND statements if any other textfield has data
                    if(!itemNameSearchField.getText().isEmpty() || !modelNoSearchField.getText().isEmpty() || conditionSearchBox.getValue() != null)
                    {
                       searchQuery = searchQuery + " AND ";
                    }
                    
                   
                }
                
                //if the item name box is not empty, add data to query
                if(!itemNameSearchField.getText().isEmpty())
                {
                   String nameString = "item_name LIKE " + "'" + itemNameSearchField.getText() + "%'";
                   searchQuery = searchQuery + nameString;
                   //checks to add AND statements if any other textfield has data
                   if(!modelNoSearchField.getText().isEmpty() || conditionSearchBox.getValue() != null)
                   {
                      searchQuery = searchQuery + " AND ";
                   }
                   
                }
                //if the model number box is not empty, add data to query
                if(!modelNoSearchField.getText().isEmpty())
                {
                    
                    String modelString = "model_no LIKE " + "'" + modelNoSearchField.getText() + "%'";
                    searchQuery = searchQuery + modelString;
                    //checks to add AND statements if any other textfield has data
                    if(conditionSearchBox.getValue() != null)
                    {
                       searchQuery = searchQuery + " AND ";
                    }
                    
                   
                }
                
                //if the condition choice box is not empty, add data to query
                if(conditionSearchBox.getValue() != null)
                {
                   String modelString = "item_condition = " + "'" + conditionSearchBox.getValue().toString() + "'";
                   searchQuery = searchQuery + modelString;
                                     
                }
                
                //test
                System.out.println(searchQuery);
                
                //process the results into the table
                ResultSet rs = stmt.executeQuery(searchQuery);
                boolean empty = true; // true if no results are found in the database
                
                while(rs.next())
                {
                    //get the location using the items location ID
                    Location resultLocation = new Location(rs.getInt("location_ID"));
                    String place = resultLocation.determinePlace();
                    //populate each item as a row in the table
                    ItemTable entry = new ItemTable(rs.getInt("inventory_ID"), place , rs.getInt("invoice_ID"), rs.getString("item_name"),rs.getString("model_No"), rs.getString("item_condition"));
                    itemData.add(entry);

                   
                
                    empty = false; //false if there is data in the Result Set
                }
                //if there is no data display a message
                if(empty == true)
                {
                    Alert emptyAlert = new Alert(Alert.AlertType.INFORMATION);
                    emptyAlert.setTitle("NO INFORMATION FOUND");
                    emptyAlert.setHeaderText("No item with that information");
                    emptyAlert.showAndWait();
                }
                //close the connections
                rs.close();
                stmt.close();
                conn.close();
                
            }
             catch(SQLException e)
             {
                 System.out.println("Failed to search the inventory table");
                 e.printStackTrace();
                         
             }
             
        }        
    }
    @FXML
    /*
    *Handles when an item in the row is double clicked
    */
    private void handleItemRowSelection(MouseEvent event) throws IOException
    {
        if(event.isPrimaryButtonDown() && event.getClickCount() == 2)
        {
            try 
            {               
                //uses the username of the double clicked row to populate a searchedCustomer
                ItemTable itemSearch = itemSearchTable.getSelectionModel().getSelectedItem();
                System.out.println(itemSearch.getRInventoryID());
                
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("Select * FROM inventory WHERE inventory_ID = '" + itemSearch.getRInventoryID() + "'");
                
                
                while(rs.next())
                {
                   currentItem = new SearchedItem(rs.getInt("inventory_ID"), rs.getInt("location_ID"), rs.getInt("invoice_ID"), rs.getString("item_name"), rs.getString("model_no"), rs.getString("date_of_purchase"), rs.getString("item_condition"), rs.getString("note"));
                    //test 
                    System.out.println(currentItem.getDateOfPurchase()+ currentItem.getLocationID() + currentItem.getNote());
                }
                
                //creates a pop up window with various options
                Alert options = new Alert(Alert.AlertType.CONFIRMATION);
                options.setTitle("ITEM NAME: " + currentItem.getItemName() +" ITEM NUMBER: " + currentItem.getInventoryID());
                options.setHeaderText(currentItem.getNote());
                options.setContentText("Select an option");
                
                ButtonType editButton = new ButtonType("Edit");
                ButtonType deleteButton = new ButtonType("Delete");
                ButtonType cancelButton = new ButtonType ("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                
                options.getButtonTypes().setAll(editButton, deleteButton, cancelButton);
                Optional <ButtonType> result = options.showAndWait();
                
                //opens a new window or closes
                if(result.get() == editButton)
                {
                    invController.setMainItem();
                    invController.editInventory.setDisable(false);
                    invController.searchInventory.setDisable(true);
                    invController.addInventory.setDisable(true);
                    invController.inventoryTabPane.getSelectionModel().select(invController.editInventory); 
                    
                    
                }
                if(result.get() == deleteButton)
                {
                   Alert delete = new Alert(Alert.AlertType.CONFIRMATION);
                    delete.setTitle("Item Name: " + currentItem.getItemName() +" Item #: " + currentItem.getInventoryID());
                    delete.setHeaderText("Delete this item");
                    delete.setContentText("Are you sure you want to delete this item?"); 
                    Optional<ButtonType> delResult = delete.showAndWait();
                    if (delResult.get() == ButtonType.OK)
                    {
                        stmt.executeUpdate("DELETE FROM inventory WHERE inventory_ID = '" + currentItem.getInventoryID() + "'");
                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Delete Success");
                        alert.setHeaderText(null);
                        alert.setContentText("Item successfully removed");

                        alert.showAndWait();
                        
                    } else 
                    {
                        //user chose CANCEL or closed the dialog
                    }
                }
                else
                {
                    //user did not choose an option
                }
                //close the connections
                rs.close();
                stmt.close();
                conn.close();
            }
            catch(SQLException ex)
            {
                System.out.println("Failed to load item information from the database");
                ex.printStackTrace();
            }
        }
    }
    public SearchedItem getSearchedItem()
    {
        return currentItem;
    }
    
}
