/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import model.FormValidation;
import model.Location;
import model.MaskField;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class AddEmployeeTabController implements Initializable 
{
    //FXML Tags
    @FXML private TextField firstNameAddField;
    @FXML private TextField lastNameAddField;
    @FXML private TextField usernameAddField;
    @FXML private PasswordField passwordAddField;
    @FXML private PasswordField vPasswordAddField;
    
    @FXML private MaskField socialSecAddField;   
    
    @FXML private ChoiceBox locationChoiceBox;
    @FXML private ChoiceBox titleChoiceBox;
    @FXML private ChoiceBox genderChoiceBox;
    @FXML private ChoiceBox permissionChoiceBox;
    
    @FXML private DatePicker dobPicker;
    @FXML private DatePicker hireDatePicker;
    
    @FXML private Label usernameVal;
    @FXML private Label passwordVal;
    @FXML private Label vPasswordVal;
    @FXML private Label titleVal;
    @FXML private Label locationVal;   
    @FXML private Label firstNameVal;
    @FXML private Label lastNameVal;
    @FXML private Label genderVal;
    @FXML private Label dobVal;
    @FXML private Label hireDateVal;
    @FXML private Label socSecVal;
    @FXML private Label permissionVal;
    
    @FXML private Pane empAccountPane;
    @FXML private Pane empInformationPane;
    @FXML private Label validationLabel;
    
    /**
     * Adds the employee information to the database
     */
    private void addEmployee()
    {
        //initialize queries and their builders
        // builers will create the queries based on the users input
        String accountQuery = "INSERT INTO accounts (account_username, account_password, permission_level) VALUES("; //Holds the beginnings of a search query
        String accountBuilder = "";
        
        String infoQuery = "INSERT INTO employees (account_username, location_ID, title, first_name, last_name, birth_date, gender, hire_date, social_security) VALUES (";
        String infoBuilder = "";
        
        //show alert box to make sure information is correct
        Alert infoCorrect = new Alert(Alert.AlertType.CONFIRMATION);
        infoCorrect.setTitle("Confirm Information");
        infoCorrect.setHeaderText("Are you sure?");
        infoCorrect.setContentText("Username: " + usernameAddField.getText() + "\nTitle: " + titleChoiceBox.getValue().toString() +
                                   "\nFirst Name: " + firstNameAddField.getText() +"\nLast Name: " + lastNameAddField.getText() +
                                   "\nGender: " + genderChoiceBox.getValue().toString() + "\nDOB: " + dobPicker.getValue() +
                                   "\nHire Date: " + hireDatePicker.getValue());
        
        Optional<ButtonType> result =  infoCorrect.showAndWait();
        
        //if okay is clicked
        if(result.get() == ButtonType.OK)
        {                   
            //builds account query
            accountBuilder = "'" +usernameAddField.getText() + "', '" + passwordAddField.getText() + "', '" + permissionChoiceBox.getValue().toString() + "')";
            accountQuery = accountQuery + accountBuilder;
            System.out.println(accountQuery); //test

            //builds additional information query
            //Determine the location ID based on the selected location
                Location empLocation =  new Location(locationChoiceBox.getValue().toString());                
                infoBuilder = "'" + usernameAddField.getText() + "', " + empLocation.determineLocationID() + ", '" + titleChoiceBox.getValue().toString() + "', '" + firstNameAddField.getText() 
                        + "', '" + lastNameAddField.getText() + "', '" + dobPicker.getValue().toString() + "', '" + genderChoiceBox.getValue().toString() + "', '" + hireDatePicker.getValue().toString()+ "', '" + socialSecAddField.getText().replaceAll("\\D+","") + "')"; 

                infoQuery = infoQuery + infoBuilder;
                System.out.println(infoQuery); //test
                
                //connect and perform the sql statements
                try
                {
                    //connect to the database and create statement
                    Connection conn = SqlConnection.DBconnect();
                    java.sql.Statement stmt = conn.createStatement();
                    
                    
                    stmt.executeUpdate(accountQuery);
                    System.out.println("Account successfully added");
                    
                    stmt.executeUpdate(infoQuery);
                    System.out.println("Information added successfully");
                    
                    //displays success box
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Employee Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Employee successfully added");

                    alert.showAndWait();
                    clear();
                    
                    //close the connections
                    stmt.close();
                    conn.close();
                }
                catch(SQLException e)
                {
                    System.out.println("Failed to add new employee");
                    e.printStackTrace();
                }
        }
    }
    @FXML
    /*
    *calls the clear method when button is clicked
    */
    private void handleClearButton(ActionEvent event)
    {
        clear();
        
    }
    /**
     * clears all the data and resets the focus
     */
    private void clear()
    {
        usernameAddField.clear();
        passwordAddField.clear();
        vPasswordAddField.clear();
        firstNameAddField.clear();
        lastNameAddField.clear();
        permissionChoiceBox.setValue(null);
        titleChoiceBox.setValue(null);
        dobPicker.setValue(null);
        genderChoiceBox.setValue(null);
        hireDatePicker.setValue(null);
        locationChoiceBox.setValue(null);
        socialSecAddField.setMask("___-__-____");
        socialSecAddField.setMask("DDD-DD-DDDD");
        locationChoiceBox.setValue("");
        usernameAddField.requestFocus();
        validationLabel.setText("");
        usernameVal.setText("");
        passwordVal.setText("");
        vPasswordVal.setText("");
        firstNameVal.setText("");
        lastNameVal.setText("");
        permissionVal.setText("");
        titleVal.setText("");
        dobVal.setText("");
        genderVal.setText("");
        hireDateVal.setText("");
        socSecVal.setText("");
        locationVal.setText("");
        validationLabel.setText("");
        
        empInformationPane.setDisable(true);
        empAccountPane.setDisable(false);
        usernameAddField.requestFocus();
        usernameAddField.setPromptText("");
        passwordAddField.setPromptText("");
        vPasswordAddField.setPromptText("");
        firstNameAddField.setPromptText("");
        lastNameAddField.setPromptText("");
        socialSecAddField.setPromptText("");
    }
    
    @FXML
    /**
     * Validates the accountPane, makes sure information is correct, then hides pane and opens the next one
     */
    private void handleEmpAccountSubmitButton(ActionEvent event)
    {        
        //Form Validation
        boolean username = FormValidation.textFieldNotEmpty(usernameAddField, usernameVal, "*");
        boolean password = FormValidation.textFieldNotEmpty(passwordAddField, passwordVal, "*");
        boolean vPassword = FormValidation.textFieldNotEmpty(vPasswordAddField, vPasswordVal, "*");
        boolean permission = FormValidation.choiceBoxNotEmpty(permissionChoiceBox, permissionVal, "*");
        
        if(username && password && vPassword && permission)
        {
            if(passwordAddField.getText().equals(vPasswordAddField.getText()))
            {
                           
                // hides the current pane
                empAccountPane.setDisable(true);
                empInformationPane.setDisable(false);
                
                
            }
            else //if the passwords do not match give a warning
            {
                vPasswordVal.setText("Password does not match");
            }
        }
        else
        {
            validationLabel.setText("Make sure all fields are filled");
        }
    }
    
    @FXML
    /**
     * Validates the informationPane, makes sure information is correct, then hides pane and opens the next one
     */
    private void handleEmpAdditionalSubmitButton(ActionEvent event)
    {
        
        //Form Validation
        boolean title = FormValidation.choiceBoxNotEmpty(titleChoiceBox, titleVal, "*");
        boolean firstName = FormValidation.textFieldNotEmpty(firstNameAddField, firstNameVal, "*");
        boolean lastName = FormValidation.textFieldNotEmpty(lastNameAddField, lastNameVal, "*");
        boolean gender = FormValidation.choiceBoxNotEmpty(genderChoiceBox, genderVal, "*");
        boolean dob = FormValidation.datePickerNotEmpty(dobPicker, dobVal, "*");
        boolean hireDate = FormValidation.datePickerNotEmpty(hireDatePicker, hireDateVal, "*");
        boolean location = FormValidation.choiceBoxNotEmpty(locationChoiceBox, locationVal, "*");
        
        if( title && firstName && lastName && gender && !socialSecAddField.getText().equals("___-__-____") && dob && location && hireDate)
        {
                       
            //adds the employee to the database
            addEmployee();
        }
        else
        {
            validationLabel.setText("Make sure all fields are filled");
        }
        
        
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
        //disables the information pane
        empInformationPane.setDisable(true);
        //initializes choices
        locationChoiceBox.setItems(FXCollections.observableArrayList("Tucson, AZ" , "Los Angeles, CA" , "San Francisco, CA" , "Denver, CO" ,
                                                                     "Chicago, IL" , "Detroit, MI" , "Albuquerque, NM" , "Cincinnati, OH" , "Columbus, OH" ,
                                                                     "Philadelphia, PA" , "Dallas, TX" , "Houston, TX" , "Arlington, VA" , "Milwaukee, WI"));
        permissionChoiceBox.setItems(FXCollections.observableArrayList("1","2","3","4","5"));
        genderChoiceBox.setItems(FXCollections.observableArrayList("M", "F", "Other"));
        titleChoiceBox.setItems(FXCollections.observableArrayList("Mr." , "Ms." , "Mrs.", "Mx."));
        
        //add action listeners for live validation
        FormValidation.addLiveValidation(usernameAddField, "^[A-Za-z0-9]{0,20}|$", usernameVal, validationLabel, "Username must be alphanumeric\n must be 20 characters or less");
        FormValidation.addLiveValidation(passwordAddField, "(?=[A-Za-z0-9]{6,20})(?=.*[A-Za-z])(?=.*[0-9])[A-Za-z0-9]+|", passwordVal, validationLabel, "Password must be alphanumeric\n must be at least 6 characters\n must contain at least 1 number");        
        FormValidation.addLiveValidation(firstNameAddField, "^[a-zA-Z]{1,20}|$", firstNameVal, validationLabel,"name must letters only\n must be 20 letters or less");
        FormValidation.addLiveValidation(lastNameAddField, "^[a-zA-Z]{1,20}|$", lastNameVal, validationLabel,"name must letters only\n must be 20 letters or less");
        FormValidation.addLiveValidation(socialSecAddField, "^[0-9()]{3}[-]{1}[0-9]{2}[-]{1}[0-9]{4}", socSecVal, validationLabel,"Enter a valid social security number", "___-__-____", "DDD-DD-DDDD");
        
        
        
    }    
    
}
