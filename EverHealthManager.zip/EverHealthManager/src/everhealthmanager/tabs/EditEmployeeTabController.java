/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import everhealthmanager.ManagerEmployeeController;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.FormValidation;
import model.Location;
import model.SearchedEmployee;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class EditEmployeeTabController implements Initializable 
{
    //passes information to the customer controller
    private ManagerEmployeeController empController;
    public SearchedEmployee editableEmployee;
    
    @FXML ChoiceBox titleEditBox;
    @FXML ChoiceBox genderEditBox;
    @FXML ChoiceBox locationEditBox;
    @FXML ChoiceBox permissionEditBox;
    
    @FXML TextField firstNameEditField;
    @FXML TextField lastNameEditField;
    @FXML TextField usernameEditField;
    @FXML TextField passwordEditField;
    @FXML TextField vPasswordEditField;
    
    @FXML private Label usernameEditVal;
    @FXML private Label passwordEditVal;
    @FXML private Label vPasswordEditVal;
    @FXML private Label permissionEditVal;
    @FXML private Label titleEditVal;
    @FXML private Label firstNameEditVal;
    @FXML private Label lastNameEditVal;
    @FXML private Label genderEditVal;
    @FXML private Label locationEditVal;
    @FXML private Label validationLabel;
    
    
    
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //disables the usernamed edit field
        usernameEditField.setDisable(true);
        locationEditBox.setItems(FXCollections.observableArrayList("Tucson, AZ" , "Los Angeles, CA" , "San Francisco, CA" , "Denver, CO" ,
                                                                     "Chicago, IL" , "Detroit, MI" , "Albuquerque, NM" , "Cincinnati, OH" , "Columbus, OH" ,
                                                                     "Pennsylvania, PA" , "Dallas, TX" , "Houston, TX" , "Arlington, VA" , "Milwaukee, WI"));
        permissionEditBox.setItems(FXCollections.observableArrayList("1","2","3","4","5"));
        genderEditBox.setItems(FXCollections.observableArrayList("M", "F", "Other"));
        titleEditBox.setItems(FXCollections.observableArrayList("Mr." , "Ms." , "Mrs.", "Mx."));
        
        //add live validation
        FormValidation.addLiveValidation(usernameEditField, "^[A-Za-z0-9]{0,20}|$", usernameEditVal, validationLabel, "Username must be alphanumeric\n must be 20 characters or less");
        FormValidation.addLiveValidation(passwordEditField, "(?=[A-Za-z0-9]{6,20})(?=.*[A-Za-z])(?=.*[0-9])[A-Za-z0-9]+|", passwordEditVal, validationLabel, "Password must be alphanumeric\n must be at least 6 characters\n must contain at least 1 number");        
        FormValidation.addLiveValidation(firstNameEditField, "^[a-zA-Z]{1,20}|$", firstNameEditVal, validationLabel,"name must letters only\n must be 20 letters or less");
        FormValidation.addLiveValidation(lastNameEditField, "^[a-zA-Z]{1,20}|$", lastNameEditVal, validationLabel,"name must letters only\n must be 20 letters or less");
    }
    
    /**
     * initializes reference to main employee Controller
     * @param managerEmployeeController main controller
     */
    public void init(ManagerEmployeeController managerEmployeeController) 
    {
        empController = managerEmployeeController;
    }
    
    /**
     * grabs the date to be edited from the main controller
     * populates the fields
     */
    public void setEditableEmployee()
    {        
        editableEmployee = empController.getMainEmployee();
        System.out.println(editableEmployee.getFirstName());
        getEmployeeData();
    }
    /**
     * Connects to the database and populates the fields with appropriate information
     */
    public void getEmployeeData()
    {
        System.out.println("Getting employees data from database"); //test
        
        try
        {
            Connection conn = SqlConnection.DBconnect();
            java.sql.Statement stmt = conn.createStatement();
            ResultSet employeeRS = stmt.executeQuery("SELECT * FROM employees WHERE employee_ID = " + editableEmployee.getEmployeeID());
            while(employeeRS.next())
            {
                titleEditBox.setValue(employeeRS.getString("title"));
                firstNameEditField.setText(employeeRS.getString("first_name"));
                lastNameEditField.setText(employeeRS.getString("last_name"));
                genderEditBox.setValue(employeeRS.getString("gender"));
                //get the location of the employee
                Location empLocation = new Location(employeeRS.getInt("location_ID"));
                locationEditBox.setValue(empLocation.determinePlace());
            }
            ResultSet accountRS = stmt.executeQuery("SELECT * FROM accounts WHERE account_username = '" + editableEmployee.getUserName() + "'");
            while(accountRS.next())
            {
                usernameEditField.setText(accountRS.getString("account_username"));
                passwordEditField.setText(accountRS.getString("account_password"));
                vPasswordEditField.setText(accountRS.getString("account_password"));
                permissionEditBox.setValue(accountRS.getString("permission_level"));
            }
            //close the connections
            accountRS.close();
            employeeRS.close();
            stmt.close();
            conn.close();
        }
        catch(SQLException e)
        {
            System.out.println("Something went wrong generating the employee in the edit tab");
            e.printStackTrace();
        }
    }
    
    @FXML
    /**
     * handles when the Edit button is clicked
     * updates existing information
     */
    private void handleEmpEditButton(ActionEvent event)
    {
        //Form Validation
        boolean password = FormValidation.textFieldNotEmpty(passwordEditField, passwordEditVal, "*");
        boolean vPassword = FormValidation.textFieldNotEmpty(vPasswordEditField, vPasswordEditVal, "*");
        boolean permission = FormValidation.choiceBoxNotEmpty(permissionEditBox, permissionEditVal, "*");
        
        //makes sure the fields arent empty
       if(password && vPassword && permission)
       {
           //makes sure the password values match
           if(passwordEditField.getText().equals(vPasswordEditField.getText()))
           {
                //check to see if the value is already in the database
                try
                {
                    Connection conn = SqlConnection.DBconnect();
                    java.sql.Statement stmt = conn.createStatement();
                    ResultSet ePasswordRS = stmt.executeQuery("SELECT * FROM accounts WHERE account_username = '" + editableEmployee.getUserName() + "'");
                    if(ePasswordRS.next())
                    {
                        
                            stmt.executeUpdate("UPDATE accounts SET account_password = '" + passwordEditField.getText() + "', permission_level = '" + permissionEditBox.getValue().toString() + "' WHERE account_username = '" + usernameEditField.getText() + "'");
                            validationLabel.setText("Password/Permission\nsuccessfully updated");
                    }
                    //close the connections
                    ePasswordRS.close();
                    stmt.close();
                    conn.close();
                }
                catch(SQLException e)
                {
                    System.out.println("Failed to compare data in database");
                    e.printStackTrace();
                }
           }
           else
           {
               validationLabel.setText("Password does not match");
           }
       }
       else
       {
           validationLabel.setText("Make sure all fields are filled");
       }
    }
           
    @FXML
     /**
     * handles when the Edit button is clicked
     * updates existing information
     */
    private void handleEmpInfoEditButton(ActionEvent event)
    {
        //Form Validation
        boolean title = FormValidation.choiceBoxNotEmpty(titleEditBox, titleEditVal, "*");
        boolean firstName = FormValidation.textFieldNotEmpty(firstNameEditField, firstNameEditVal, "*");
        boolean lastName = FormValidation.textFieldNotEmpty(lastNameEditField, lastNameEditVal, "*");
        boolean gender = FormValidation.choiceBoxNotEmpty(genderEditBox, genderEditVal, "*");
        boolean location = FormValidation.choiceBoxNotEmpty(locationEditBox, locationEditVal, "*");
        
        if(title && firstName && lastName && gender && location)
        {
            try
            {
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                
                //determine new locationID
                //Determine the location ID based on the selected location
                
                Location empLocation = new Location(locationEditBox.getValue().toString());
                
                stmt.executeUpdate("UPDATE employees SET title = '" + titleEditBox.getValue().toString() + "', first_name = '" + firstNameEditField.getText() + 
                                   "', last_name = '" + lastNameEditField.getText() + "', gender = '" + genderEditBox.getValue().toString()
                                     + "', location_ID = " + empLocation.determineLocationID() + " WHERE account_username = '" + editableEmployee.getUserName() + "'");
                //if the update was successful
                validationLabel.setText("Information successfully updated");
                //close the connections
                stmt.close();
                conn.close();
            }
            catch(SQLException e)
            {
                System.out.println("Failed to update employee");
                e.printStackTrace();
            }
        }
        else
        {
           validationLabel.setText("Make sure all fields are filled"); 
        }
        
    }
    
    @FXML
    /*
    * returns the user to the employee search tab
    */
    private void handleReturntoSearchButton(ActionEvent ev)
    {
       empController.searchEmployee.setDisable(false);
       empController.addEmployee.setDisable(false);
       empController.employeeTabPane.getSelectionModel().select(empController.searchEmployee);
       empController.editEmployee.setDisable(true);
    }
    
}
