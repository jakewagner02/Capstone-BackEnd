/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.AccountPayableTable;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class SearchAccountsPayableTabController implements Initializable 
{
    //holds reference to the Finances main page
    
    //Holds the instance of the searched invoice
    
    //FXML Tags
    @FXML private TextField payableIDSearchField;
    
    //Define invoice Search Table
    @FXML 
    private TableView<AccountPayableTable> payableSearchTable;
    @FXML 
    private TableColumn<AccountPayableTable, Integer> iPayableID;
    @FXML 
    private TableColumn<AccountPayableTable, Integer> iInvoiceID;
    @FXML
    private TableColumn<AccountPayableTable, String> iName;
    @FXML 
    private TableColumn<AccountPayableTable, String> iDescription;
    @FXML 
    private TableColumn<AccountPayableTable, Double> iCredit;
    @FXML 
    private TableColumn<AccountPayableTable, Double> iDebit;
    @FXML 
    private TableColumn<AccountPayableTable, String> iDatePayable;
    
    //Create table data
    final ObservableList<AccountPayableTable> payableData = FXCollections.observableArrayList();
    
    @FXML
    private void handleSearchPayableButton(ActionEvent e)
    {
        searchAccPayable();
    }
    
    @FXML
    private void handlePrintButton(ActionEvent e)
    {
        Stage app_stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        PrinterJob job = PrinterJob.createPrinterJob();
 
        if(!payableData.isEmpty())
        {
            if (job != null) 
            {                    
                boolean showDialog = job.showPageSetupDialog(app_stage);
                if (showDialog) 
                {                        
                    payableSearchTable.setScaleX(0.50);
                    payableSearchTable.setScaleY(0.50);
                    payableSearchTable.setTranslateX(-200);
                    payableSearchTable.setTranslateY(-50);
                }
                boolean success = job.printPage(payableSearchTable);
                if (success) 
                {
                             job.endJob(); 
                } 
                payableSearchTable.setTranslateX(0);
                payableSearchTable.setTranslateY(0);               
                payableSearchTable.setScaleX(1.0);
                payableSearchTable.setScaleY(1.0);                                              
            } 
        }
        else
        {
            Alert noData = new Alert(Alert.AlertType.WARNING);
                   noData.setTitle("Print Job Cancelled");
                   noData.setHeaderText(null);
                   noData.setContentText("There is no information to print");
                   noData.showAndWait();
        }
       
        
    }
        
    
    
    @FXML
    private void handleClearButton()
    {
        payableIDSearchField.setText("");
        payableIDSearchField.setPromptText("");
        payableData.clear();
    }
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //initialize the item table
        iPayableID.setCellValueFactory(new PropertyValueFactory<AccountPayableTable, Integer>("rPayableID"));
        iInvoiceID.setCellValueFactory(new PropertyValueFactory<AccountPayableTable, Integer>("rInvoiceID"));
        iName.setCellValueFactory(new PropertyValueFactory<AccountPayableTable, String>("rName"));
        iDescription.setCellValueFactory(new PropertyValueFactory<AccountPayableTable, String>("rDescription"));
        iCredit.setCellValueFactory(new PropertyValueFactory<AccountPayableTable, Double>("rCredit"));
        iDebit.setCellValueFactory(new PropertyValueFactory<AccountPayableTable, Double>("rDebit"));
        iDatePayable.setCellValueFactory(new PropertyValueFactory<AccountPayableTable, String>("rDatePayable"));
        
        payableSearchTable.setItems(payableData);
        
        //live validation
        payableIDSearchField.focusedProperty().addListener((listener, oldVal, newVal)->
        {
            if(!newVal)
            {
                if(!payableIDSearchField.getText().matches("^[0-9]{0,11}|$"))
                {
                   payableIDSearchField.setText("");
                   payableIDSearchField.setPromptText("Enter Numbers Only");
                   
                }
                else
                {
                    payableIDSearchField.setPromptText("");                   
                }
            }
        });
    }

    private void searchAccPayable()
    {
        //clear any data currently in the table
        payableData.clear();
        
        System.out.println("You clicked the account payable search button"); //test
        
        //Simplified Validation
        //If invoice field is empty, display an error   
        if(payableIDSearchField.getText().isEmpty())
        {
            Alert noInput = new Alert(Alert.AlertType.WARNING);
                   noInput.setTitle("Warning");
                   noInput.setHeaderText(null);
                   noInput.setContentText("Please enter an account payable ID");
                   noInput.showAndWait();
        }
        else
        {
            //connect to the database and search
            try
            {
                Connection conn = SqlConnection.DBconnect();
                conn.setAutoCommit(false);
                java.sql.Statement stmt = conn.createStatement();
                String query = "SELECT accounts_payable.account_payable_ID, accounts_payable.invoice_ID, accounts_payable.name, accounts_payable.description, accounts_payable.credit, accounts_payable.debit, accounts_payable.payable_date FROM accounts_payable WHERE accounts_payable.account_payable_ID = '" + payableIDSearchField.getText() + "'";
                
                ResultSet payableRS = stmt.executeQuery(query);
                
                boolean empty = true; // true if no results are found in the database

                //    
                while(payableRS.next())
                {
                    AccountPayableTable entry = new AccountPayableTable(payableRS.getInt("account_payable_ID"), payableRS.getInt("invoice_ID"), payableRS.getString("name"), payableRS.getString("description"),payableRS.getDouble("credit"), payableRS.getDouble("debit"), payableRS.getDate("payable_date").toString());
                    payableData.add(entry);

                   
                
                    empty = false; //false if there is data in the Result Set
                }
                
                //if there is no data display a message
                if(empty == true)
                {
                    Alert emptyAlert = new Alert(Alert.AlertType.INFORMATION);
                    emptyAlert.setTitle("NO INFORMATION FOUND");
                    emptyAlert.setHeaderText("No Account with that information");
                    emptyAlert.showAndWait();
                }
                //close the connections
                payableRS.close();
                stmt.close();
                conn.close();
            }
            catch(SQLException e)
            {
                System.out.println("Failed to search the finances table");
                e.printStackTrace();
            }

        }
    }
    
    
}
