/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import everhealthmanager.EmployeeInventoryController;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import model.FormValidation;
import model.Location;
import model.SearchedItem;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class EditItemTabController implements Initializable 
{
    //passes information to the customer controller
    private EmployeeInventoryController invController;
    public SearchedItem editableItem;
    
    //FXML tags
    @FXML private TextField IDEditField;
    @FXML private TextField invoiceEditField;
    @FXML private TextField nameEditField;
    @FXML private TextField modelNoEditField;
    
    @FXML private TextArea noteEditArea;
    
    @FXML private ChoiceBox locationEditBox;
    @FXML private ChoiceBox conditionEditBox;
    
    @FXML private DatePicker dopEditPicker;
    
    @FXML private Label locationVal;
    @FXML private Label invoiceVal;
    @FXML private Label nameVal;
    @FXML private Label modelNoVal;
    @FXML private Label dopVal;
    @FXML private Label conditionVal;
    
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //set location items
        locationEditBox.setItems(FXCollections.observableArrayList("Tucson, AZ" , "Los Angeles, CA" , "San Francisco, CA" , "Denver, CO" ,
                                                                     "Chicago, IL" , "Detroit, MI" , "Albuquerque, NM" , "Cincinnati, OH" , "Columbus, OH" ,
                                                                     "Philadelphia, PA" , "Dallas, TX" , "Houston, TX" , "Arlington, VA" , "Milwaukee, WI"));
        
        conditionEditBox.setItems(FXCollections.observableArrayList("new", "excellent", "very good", "good","fair","bad","needs-replaced"));
        
        IDEditField.setDisable(true);
        invoiceEditField.setDisable(true);
        
        //live validation
        modelNoEditField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!modelNoEditField.getText().matches("^[0-9]{1,11}$"))
                       {
                       
                           modelNoEditField.setText("");
                           modelNoEditField.setPromptText("Enter a Valid Number");
                       }
                   }
               });
    }    

    public void init(EmployeeInventoryController employeeInventoryController) 
    {
        invController = employeeInventoryController;
    }
    
    public void setEditableItem()
    {        
        editableItem = invController.getMainItem();
        System.out.println(editableItem.getItemName());
        getItemData();
    }
    public void getItemData()
    {
        System.out.println("Getting item data from database"); //test
        
        try
        {
            Connection conn = SqlConnection.DBconnect();
            java.sql.Statement stmt = conn.createStatement();
            ResultSet itemRS = stmt.executeQuery("SELECT * FROM inventory WHERE inventory_ID = " + editableItem.getInventoryID());
            while(itemRS.next())
            {
               IDEditField.setText(itemRS.getString("inventory_ID"));
               invoiceEditField.setText(itemRS.getString("invoice_ID"));
               nameEditField.setText(itemRS.getString("item_name"));
               dopEditPicker.setValue(itemRS.getDate("date_of_purchase").toLocalDate());
               modelNoEditField.setText(itemRS.getString("model_No"));
               conditionEditBox.setValue(itemRS.getString("item_condition"));
               noteEditArea.setText(itemRS.getString("note"));
               
            }
            //gets the location from the locationID and sets it to the textbox
            ResultSet locationRS = stmt.executeQuery("SELECT * FROM location WHERE location_ID = " + editableItem.getLocationID());
            while(locationRS.next())
            {
                String locationString = locationRS.getString("city") + ", " + locationRS.getString("state");
                System.out.println("This is the location: " + locationString);
                locationEditBox.setValue(locationString);
            }
            //close the connections
            locationRS.close();
            itemRS.close();
            stmt.close();
            conn.close();
            
        }
        catch(SQLException ex)
        {
            System.out.println("Failed to transfer information to the edit tab");
            ex.printStackTrace();
        }
    }
    
    @FXML
    private void handleCancelEditButton(ActionEvent ev)
    {
       invController.searchInventory.setDisable(false);
       invController.addInventory.setDisable(false);
       invController.inventoryTabPane.getSelectionModel().select(invController.searchInventory);
       invController.editInventory.setDisable(true);
    }
    @FXML
    /**
     * validates the fields then updates the item
     * @param event 
     */
    private void handleItemUpdateButton(ActionEvent event)
    {
        //Form Validation
        boolean location = FormValidation.choiceBoxNotEmpty(locationEditBox, locationVal, "*field required");
        boolean name = FormValidation.textFieldNotEmpty(nameEditField, nameVal, "*field required");
        boolean modelNo = FormValidation.textFieldNotEmpty(modelNoEditField, modelNoVal, "*field required");
        boolean condition = FormValidation.choiceBoxNotEmpty(conditionEditBox, conditionVal, "*field required");
        boolean date = FormValidation.datePickerNotEmpty(dopEditPicker, dopVal, "*date required");
        
        if(location && name && modelNo && condition && date)
        {
            try
            {
                //create new location object
                Location editableLocation = new Location(locationEditBox.getValue().toString());
                
                //connect to the database                
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                
                //make sure the invoice ID is in the database
                ResultSet invoiceRS = stmt.executeQuery("SELECT * FROM invoices WHERE invoice_ID = " + invoiceEditField.getText());
                if(invoiceRS.next())
                {
                
                    stmt.executeUpdate("UPDATE inventory SET location_ID = '" + editableLocation.determineLocationID() + "', invoice_ID = '" + invoiceEditField.getText() + 
                                       "',item_name = '" + nameEditField.getText() + "', model_no = '" + modelNoEditField.getText() + "', date_of_purchase = '"
                                        + dopEditPicker.getValue().toString() + "', item_condition = '" + conditionEditBox.getValue().toString() + 
                                        "', note = '" + noteEditArea.getText() + "' WHERE inventory_ID = '" + editableItem.getInventoryID() + "'");
                    
                    
                    Alert success = new Alert(AlertType.INFORMATION);
                    success.setTitle(nameEditField.getText());
                    success.setHeaderText(null);
                    success.setContentText("Item Successfully Updated");

                    success.showAndWait();
                }
                else
                {
                    Alert wrongID = new Alert(AlertType.INFORMATION);
                    wrongID.setTitle("No Invoice");
                    wrongID.setHeaderText(null);
                    wrongID.setContentText("There is no invoice with that number");

                    wrongID.showAndWait();
                }
                //close the connections
                invoiceRS.close();
                stmt.close();
                conn.close();
            }
            catch(SQLException ex)
            {
                System.out.println("Failed to update the item");
                ex.printStackTrace();
            }
        }
        
        
    }
    
    
}
