/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import everhealthmanager.EmployeeCustomerController;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.AutoComboBox;
import model.FormValidation;
import model.Location;
import model.MaskField;
import model.Month;
import model.SearchedCustomer;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author Jake
 */
public class EditCustomerTabController implements Initializable 
{
    //passes information to the customer controller
    private EmployeeCustomerController custController;
    public SearchedCustomer editableCust;
    
    //FXML tags for edit customer tab
    @FXML private TextField firstNameEditField;
    @FXML private TextField lastNameEditField;
    @FXML private MaskField phoneEditField;
    @FXML private TextField emailEditField;
    @FXML private TextField usernameEditField;
    @FXML private TextField passwordEditField;
    @FXML private TextField vPasswordEditField;
    @FXML private TextField lineOneEditField;
    @FXML private TextField lineTwoEditField;
    @FXML private TextField cityEditField;
    @FXML private MaskField zipEditField;
    @FXML private ChoiceBox paymentEditBox;
    @FXML private MaskField cardEditField;
    @FXML private MaskField cvvEditField;
    @FXML private TextField holderEditField;
    
    @FXML private ComboBox stateEditComboBox;
    
    @FXML private ChoiceBox locationEditChoiceBox;
    @FXML private ChoiceBox titleEditChoiceBox;
    @FXML private ChoiceBox genderEditChoiceBox;
    @FXML private ChoiceBox membershipEditChoiceBox;
    @FXML private ChoiceBox monthEditChoiceBox;
    @FXML private ChoiceBox yearEditChoiceBox;
    
    //all of the validation labels
    @FXML private Label passwordEditVal;
    @FXML private Label vPasswordEditVal;
    @FXML private Label lineOneEditVal;
    @FXML private Label cityEditVal;
    @FXML private Label stateEditVal;
    @FXML private Label zipEditVal;
    @FXML private Label titleEditVal;
    @FXML private Label firstNameEditVal;
    @FXML private Label lastNameEditVal;
    @FXML private Label genderEditVal;
    @FXML private Label phoneEditVal;
    @FXML private Label emailEditVal;
    @FXML private Label locationEditVal;
    @FXML private Label membershipEditVal;
    @FXML private Label paymentEditVal;
    @FXML private Label cardEditVal;
    @FXML private Label expirationEditVal;
    @FXML private Label cvvEditVal;
    @FXML private Label holderEditVal;
    @FXML private Label validationLabel;
    @FXML private Label lineTwoEditVal;
    @FXML private Label usernameEditVal;
    
    
    
    
    
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //disables the username edit field, should not be changed
        usernameEditField.setDisable(true);
        
        //populates the various choiceBoxes
        paymentEditBox.setItems(FXCollections.observableArrayList("Visa","MasterCard","American Express"));
        membershipEditChoiceBox.setItems(FXCollections.observableArrayList("bronze", "silver", "gold", "canceled"));
        titleEditChoiceBox.setItems(FXCollections.observableArrayList("Mr." , "Ms." , "Mrs.", "Mx."));
        locationEditChoiceBox.setItems(FXCollections.observableArrayList("Tucson, AZ" , "Los Angeles, CA" , "San Francisco, CA" , "Denver, CO" ,
                                                                     "Chicago, IL" , "Detroit, MI" , "Albuquerque, NM" , "Cincinnati, OH" , "Columbus, OH" ,
                                                                     "Philadelphia, PA" , "Dallas, TX" , "Houston, TX" , "Arlington, VA" , "Milwaukee, WI"));
        monthEditChoiceBox.setItems(FXCollections.observableArrayList("January", "February", "March" , "April", "May" , "June", "July", "August", "September", "October", "November", "December"));
        genderEditChoiceBox.setItems(FXCollections.observableArrayList("M", "F", "Other"));
        stateEditComboBox.setItems(FXCollections.observableArrayList("AK","AL","AR","AZ","CA","CO","CT","DC","DE","FL",
                                                                 "GA","GU","HI","IA","ID", "IL","IN","KS","KY","LA",
                                                                 "MA","MD","ME","MH","MI","MN","MO","MS","MT","NC",
                                                                 "ND","NE","NH","NJ","NM","NV","NY", "OH","OK","OR",
                                                                 "PA","PR","PW","RI","SC","SD","TN","TX","UT","VA",
                                                                 "VI","VT","WA","WI","WV","WY"));
        
        //makes the state combo box autocomplete        
        new AutoComboBox<>(stateEditComboBox);
        passwordEditField.setPromptText("Enter a new Password");
        //get the year        
        for(int i = 0; i <=20; i++)
        {
            int year = 2016;
            year = year + i;
            yearEditChoiceBox.getItems().add(i, year);
        }
        
        //add action listeners for live validation
        FormValidation.addLiveValidation(usernameEditField, "^[A-Za-z0-9]{0,20}|$", usernameEditVal, validationLabel,"Username must be alphanumeric\n must be 20 characters or less");
        FormValidation.addLiveValidation(passwordEditField, "(?=[A-Za-z0-9]{6,20})(?=.*[A-Za-z])(?=.*[0-9])[A-Za-z0-9]+|", passwordEditVal, validationLabel,"Password must be alphanumeric\n must be at least 6 characters\n must contain at least 1 number");      
        FormValidation.addLiveValidation(lineOneEditField, "^[A-Za-z0-9 ]{0,60}|$", lineOneEditVal, validationLabel,"Address must be alphanumeric\n must be 60 characters or less");
        FormValidation.addLiveValidation(lineTwoEditField, "^[A-Za-z0-9 ]{0,60}|$", lineTwoEditVal, validationLabel,"Address must be alphanumeric\n must be 60 characters or less");
        FormValidation.addLiveValidation(cityEditField, "^[A-Za-z0-9 ]{0,60}|$", cityEditVal, validationLabel,"City must be letters only \n must be 30 letters or less");      
        FormValidation.addLiveValidation(emailEditField, "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])|",
                                         emailEditVal, validationLabel,"Enter a valid E-mail address");         
        FormValidation.addLiveValidation(zipEditField, "^[0-9]{5}|$", zipEditVal, validationLabel,"Zip must contain 5 digits","_____","DDDDD");
        FormValidation.addLiveValidation(firstNameEditField, "^[a-zA-Z]{1,20}|$", firstNameEditVal, validationLabel,"name must letters only\n must be 20 letters or less");
        FormValidation.addLiveValidation(lastNameEditField, "^[a-zA-Z]{1,20}|$", lastNameEditVal, validationLabel,"name must letters only\n must be 20 letters or less");
        FormValidation.addLiveValidation(phoneEditField, "^[0-9()]{8}[-]{1}[0-9]{4}", phoneEditVal, validationLabel,"Phone number must be 10 digits", "(___)___-____", "(DDD)DDD-DDDD");
        FormValidation.addLiveValidation(cvvEditField, "^[0-9]{3}", cvvEditVal, validationLabel,"CVV must be 3 digits", "___", "DDD");
        FormValidation.addLiveValidation(cardEditField, "^[0-9]{4}[-]{1}[0-9]{4}[-]{1}[0-9]{4}[-]{1}[0-9]{4}", cardEditVal, validationLabel,"Card number must be 10 digits", "____-____-____-____", "DDDD-DDDD-DDDD-DDDD");

        
        
        
        
        
    }
    
    public void init(EmployeeCustomerController employeeCustomerController)
    {
        custController = employeeCustomerController;
    }
    
    public void setEditableCustomer()
    {        
        editableCust = custController.getMainCustomer();
        System.out.println(editableCust.getFirstName());
        getData();
    }
    /**
     * gets searched data from the database and insert it into the textfields
     */
    public void getData()
    {
        System.out.println("Getting data from database");
        try
        {
            Connection conn = SqlConnection.DBconnect();
            conn.setAutoCommit(false);
            java.sql.Statement stmt = conn.createStatement();
            ResultSet customerRS = stmt.executeQuery("SELECT * FROM customer WHERE customer_ID = " + editableCust.getCustomerID());
            while(customerRS.next())
            {
               usernameEditField.setText(customerRS.getString("account_username"));
               titleEditChoiceBox.setValue(customerRS.getString("title"));
               firstNameEditField.setText(customerRS.getString("first_name"));
               lastNameEditField.setText(customerRS.getString("last_name"));
               genderEditChoiceBox.setValue(customerRS.getString("gender"));
               phoneEditField.setText(customerRS.getString("phone"));
               emailEditField.setText(customerRS.getString("email"));
               
            }
            ResultSet locationRS = stmt.executeQuery("SELECT * FROM location WHERE location_ID = " + editableCust.getLocationID());
            while(locationRS.next())
            {
                String locationString = locationRS.getString("city") + ", " + locationRS.getString("state");
                System.out.println("This is the location: " + locationString);
                locationEditChoiceBox.setValue(locationString);
            }
            
            ResultSet addressRS = stmt.executeQuery("SELECT * FROM address WHERE address_ID = " + editableCust.getAddressID());
            while(addressRS.next())
            {
                lineOneEditField.setText(addressRS.getString("address"));
                lineTwoEditField.setText(addressRS.getString("address2"));
                cityEditField.setText(addressRS.getString("city"));
                stateEditComboBox.setValue(addressRS.getString("state"));
                zipEditField.setText(addressRS.getString("zip"));
            }
            
            ResultSet membershipRS = stmt.executeQuery("SELECT * FROM membership WHERE membership_ID = " + editableCust.getMembershipID());
            int memberPayID = 0; // remembers the users payment id to pull up card information
            while(membershipRS.next())
            {
               membershipEditChoiceBox.setValue(membershipRS.getString("plan"));
               memberPayID = membershipRS.getInt("payment_ID");
            }
            
            String paymentQuery = "SELECT * FROM payment WHERE payment_ID = " + memberPayID;
            System.out.println(paymentQuery);
            ResultSet paymentRS = stmt.executeQuery(paymentQuery);
            while(paymentRS.next())
            {
                System.out.println(paymentRS.getString("payment_type"));
                paymentEditBox.setValue(paymentRS.getString("payment_type"));
                cardEditField.setText(paymentRS.getString("card_number"));
                cvvEditField.setText(paymentRS.getString("cvv"));
                holderEditField.setText(paymentRS.getString("card_holder"));
                //get the date for each choicebox
                String[] date = paymentRS.getString("expiration_date").split("-");
                String year = date[0];
                String month = date[1];
                System.out.println("the year: " + date[0]);
                System.out.println("the month: " + date[1]);
                Month monthName = new Month(Integer.parseInt(month));
                System.out.println("also the month: " + monthName.determineMonthName());
                //set the values
                yearEditChoiceBox.setValue(Integer.parseInt(year));
                monthEditChoiceBox.setValue(monthName.determineMonthName());
                
                
                
            }
         //close the connections
         paymentRS.close();
         membershipRS.close();
         addressRS.close();
         locationRS.close();
         customerRS.close();
         stmt.close();
         conn.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    
    
    
    @FXML
    /**
     * updates the password if the edit button is clicked
     */
    private void handleEditPasswordButton(ActionEvent event) throws IOException
    {
       //form validation
       boolean editPassword = FormValidation.textFieldNotEmpty(passwordEditField, passwordEditVal, "*");
       boolean editVPassword = FormValidation.textFieldNotEmpty(vPasswordEditField, vPasswordEditVal, "*");
       
       //makes sure the fields arent empty
       if(editPassword && editVPassword)
       {
           //makes sure the password values match
           if(passwordEditField.getText().equals(vPasswordEditField.getText()))
           {
                //check to see if the value is already in the database
                try
                {
                    Connection conn = SqlConnection.DBconnect();
                    java.sql.Statement stmt = conn.createStatement();
                    ResultSet ePasswordRS = stmt.executeQuery("SELECT * FROM accounts WHERE account_username = '" + editableCust.getUsername() + "'");
                    if(ePasswordRS.next())
                    {
                        //if the password is the same as in the database
                        if(ePasswordRS.getString("account_password").equals(passwordEditField.getText()))
                        {
                            validationLabel.setText("That is already the password");
                        }
                        else
                        {
                            stmt.executeUpdate("UPDATE accounts SET account_password = '" + passwordEditField.getText() + "' WHERE account_username = '" + usernameEditField.getText() + "'");
                            validationLabel.setText("Password successfully updated");
                        }
                    }
                    //close the connections
                    ePasswordRS.close();
                    stmt.close();
                    conn.close();
                }
                
                catch(SQLException e)
                {
                    System.out.println("Failed to compare data in database");
                    e.printStackTrace();
                }
                
           }
           else
           {
               vPasswordEditVal.setText("Passwords must match");
           }
                
           
           
       }
    }
    @FXML private void handleAddressEditButton(ActionEvent e)
    {
        //FormValidation
        boolean lineOneEdit = FormValidation.textFieldNotEmpty(lineOneEditField, lineOneEditVal, "*");
        boolean cityEdit = FormValidation.textFieldNotEmpty(cityEditField, cityEditVal, "*");
        boolean stateEdit = FormValidation.comboBoxNotEmpty(stateEditComboBox, stateEditVal, "*");
        
        //makes sure the fields arent empty
        if(lineOneEdit && cityEdit && stateEdit && !zipEditField.getText().equals("_____"))
        {
            try
            {
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                stmt.executeUpdate("UPDATE address SET address = '" + lineOneEditField.getText() + "', address2 = '" + lineTwoEditField.getText() + 
                                   "', city = '" + cityEditField.getText() + "', state = '" + stateEditComboBox.getValue().toString() + "', zip = '"
                                    + zipEditField.getText() + "' WHERE address_ID = '" + editableCust.getAddressID() + "'");
                validationLabel.setText("Address successfully updated");
                //close the connections
                stmt.close();
                conn.close();
            }
            catch(SQLException ex)
            {
                System.out.println("Failed to update address");
                ex.printStackTrace();
            }
            
        }
        else
        {
            validationLabel.setText("Make sure all fields are filled");
        }
    }
    
    @FXML 
    private void handleAdditionalEditButton(ActionEvent e)
    {
        //FormValidation
        boolean titleEdit = FormValidation.choiceBoxNotEmpty(titleEditChoiceBox, titleEditVal, "*");
        boolean firstNameEdit = FormValidation.textFieldNotEmpty(firstNameEditField, firstNameEditVal, "*");
        boolean lastNameEdit = FormValidation.textFieldNotEmpty(lastNameEditField, lastNameEditVal, "*");
        boolean genderEdit = FormValidation.choiceBoxNotEmpty(genderEditChoiceBox, genderEditVal, "*");
        boolean emailEdit = FormValidation.textFieldNotEmpty(emailEditField, emailEditVal, "*");
        boolean locationEdit = FormValidation.choiceBoxNotEmpty(locationEditChoiceBox, locationEditVal, "*");       
        
        //makes sure the fields arent empty
        if(titleEdit && firstNameEdit && lastNameEdit && genderEdit && !phoneEditField.getText().equals("(___)___-____") && emailEdit && locationEdit)
        {
            try
            {
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                
                //determine new locationID
                //Determine the location ID based on the selected location
                
                Location custLocation = new Location(locationEditChoiceBox.getValue().toString());
                           
                
                stmt.executeUpdate("UPDATE customer SET title = '" + titleEditChoiceBox.getValue().toString() + "', first_name = '" + firstNameEditField.getText() + 
                                   "', last_name = '" + lastNameEditField.getText() + "', gender = '" + genderEditChoiceBox.getValue().toString() + "', phone = '"
                                    + phoneEditField.getText() + "', email = '" + emailEditField.getText() + "', location_ID = " + custLocation.determineLocationID() + " WHERE address_ID = '" + editableCust.getAddressID() + "'");
                //updates the locationID in the payment field
                stmt.executeUpdate("Update payment SET location_ID = " + custLocation.determineLocationID() + " WHERE account_username = '" + editableCust.getUsername() + "'");
                validationLabel.setText("Information successfully updated");
                
                //close the connections
                stmt.close();
                conn.close();
            }
            catch(SQLException ex)
            {
                System.out.println("Failed to update information");
                ex.printStackTrace();
            }
            
        }
        else
        {
            validationLabel.setText("Make sure all fields are filled");
        }
    }
    @FXML
    private void handleMembershipEditButton(ActionEvent e)
    {
        //Form Validation
        boolean membershipEdit = FormValidation.choiceBoxNotEmpty(membershipEditChoiceBox, membershipEditVal, "*");
        if(membershipEdit)
        {
            try
            {
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                
                //get new plan and rate
                String plan = membershipEditChoiceBox.getValue().toString();
                double rate = 0;
                switch(plan) //WILL NEED UPDATED
                {
                    case "bronze":
                        rate = 10.00;
                        break;
                    case "silver":
                        rate = 20.00;
                        break;
                    case "gold":
                        rate = 30.00;
                        break;

                }
                stmt.executeUpdate("UPDATE membership SET plan = '" + membershipEditChoiceBox.getValue().toString() + "', rate = " + rate + " WHERE membership_ID = '" + editableCust.getMembershipID() + "'");
                validationLabel.setText("Membership successfully updated");
                
                //close the connections
                stmt.close();
                conn.close();
            }
            catch(SQLException ex)
            {
                System.out.println("Failed to update membership");
                ex.printStackTrace();
            }
        }
        else
        {
            validationLabel.setText("Make sure all fields are filled");
        }
    }
    @FXML private void handlePaymentEditButton(ActionEvent e)
    {
        //FormValidation
        boolean paymentEdit = FormValidation.choiceBoxNotEmpty(paymentEditBox, paymentEditVal, "*");
        boolean monthEdit = FormValidation.choiceBoxNotEmpty(monthEditChoiceBox, expirationEditVal, "*");
        boolean yearEdit = FormValidation.choiceBoxNotEmpty(yearEditChoiceBox, expirationEditVal, "*");
        boolean cvvEdit = FormValidation.textFieldNotEmpty(cvvEditField, cvvEditVal, "*");
        boolean holderEdit = FormValidation.textFieldNotEmpty(holderEditField, holderEditVal, "*");
        
        //makes sure the fields arent empty
        if(paymentEdit && !cardEditField.getText().equals("____-____-____-____") && monthEdit && yearEdit && !cvvEditField.equals("___") && holderEdit)
        {
            try
            {
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                Month month = new Month(monthEditChoiceBox.getValue().toString());
                stmt.executeUpdate("UPDATE payment SET payment_type = '" + paymentEditBox.getValue().toString() + "', card_number = '" + cardEditField.getText().replaceAll("\\D+","") + 
                                  "', expiration_date = '" + 
                                     yearEditChoiceBox.getValue().toString() + "-" + month.determineMonthInt() + "-01" + //builds the date
                                    "', cvv = '" + cvvEditField.getText() + "', card_holder = '"
                                   + holderEditField.getText() + "' WHERE account_username = '" + editableCust.getUsername() + "'");
                validationLabel.setText("Payment successfully updated");
                
                //close the connections
                stmt.close();
                conn.close();
            }
            catch(SQLException ex)
            {
                System.out.println("Failed to update Payment");
                ex.printStackTrace();
            }            
        }
        else
        {
            validationLabel.setText("Make sure all fields are filled");
        }
    }    
    
    @FXML
    /*
    * returns the user to the customer search tab
    */
    private void handleReturntoSearchButton(ActionEvent ev)
    {
       custController.searchCustomer.setDisable(false);
       custController.addCustomer.setDisable(false);
       custController.customerTabPane.getSelectionModel().select(custController.searchCustomer);
       custController.editCustomer.setDisable(true);
    }
    
}
