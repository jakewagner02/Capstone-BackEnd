/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import model.FormValidation;
import model.FxUtilTest;
import model.Location;
import model.MaskField;
import model.Month;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author Jake
 */
public class AddCustomerTabController implements Initializable 
{
    
    //FXML tags for add customer tab
    @FXML private TextField firstNameAddField;
    @FXML private TextField lastNameAddField;
    @FXML private MaskField phoneAddField; //Will be mask field
    @FXML private TextField emailAddField;
    @FXML private TextField usernameAddField;
    @FXML private TextField passwordAddField;
    @FXML private TextField vPasswordAddField;
    @FXML private TextField lineOneAddField;
    @FXML private TextField lineTwoAddField;
    @FXML private TextField cityAddField;
    @FXML private MaskField zipAddField;
    @FXML private MaskField cardAddField;
    @FXML private MaskField cvvAddField;
    @FXML private TextField holderAddField;
    
    @FXML private ComboBox stateComboBox;
    
    @FXML private ChoiceBox locationChoiceBox;
    @FXML private ChoiceBox titleChoiceBox;
    @FXML private ChoiceBox genderChoiceBox;
    @FXML private ChoiceBox membershipChoiceBox;
    @FXML private ChoiceBox monthChoiceBox;
    @FXML private ChoiceBox yearChoiceBox;
    @FXML private ChoiceBox paymentAddBox;
    
    @FXML private Label locationVal;
    @FXML private Label usernameVal;
    @FXML private Label passwordVal;
    @FXML private Label vPasswordVal;
    @FXML private Label titleVal;
    @FXML private Label firstNameVal;
    @FXML private Label lastNameVal;
    @FXML private Label genderVal;
    @FXML private Label phoneVal;
    @FXML private Label emailVal;
    @FXML private Label membershipVal;
    @FXML private Label lineOneVal;
    @FXML private Label cityVal;
    @FXML private Label stateVal;
    @FXML private Label zipVal;
    @FXML private Label paymentVal;
    @FXML private Label cardVal;
    @FXML private Label expirationVal;
    @FXML private Label cvvVal;
    @FXML private Label holderVal;
    @FXML private Label lineTwoVal;
    
    @FXML private Label validationLabel;
    
    @FXML private Pane accountPane;
    @FXML private Pane informationPane;
    @FXML private Pane addressPane;
    @FXML private Pane paymentPane;
    @FXML private Pane membershipPane;
    
    @FXML
    /**
     * Validates the accountPane, makes sure information is correct, then hides pane and opens the next one
     */
    private void handleAccountSubmitButton(ActionEvent event)
    {        
        //Form Validation
        boolean username = FormValidation.textFieldNotEmpty(usernameAddField, usernameVal, "*field required");
        boolean password = FormValidation.textFieldNotEmpty(passwordAddField, passwordVal, "*field required");
        boolean vPassword = FormValidation.textFieldNotEmpty(vPasswordAddField, vPasswordVal, "*field required");
        
        //make sure the passwords match
        if(username && password && vPassword)
        {
                //make sure the username is not already taken
                try
                {
                    System.out.println(usernameAddField.getText());
                    System.out.println("SELECT * FROM accounts WHERE account_username = '" + usernameAddField.getText() + "'");
                    Connection conn = SqlConnection.DBconnect();
                    java.sql.Statement stmt = conn.createStatement();
                    ResultSet checkRS = stmt.executeQuery("SELECT * FROM accounts WHERE account_username = '" + usernameAddField.getText() + "'");
                    if(!checkRS.next())
                    {
                        //make sure the passwords match
                        if(passwordAddField.getText().equals(vPasswordAddField.getText()))
                        {

                            // hides the current pane
                            accountPane.setDisable(true);
                            informationPane.setDisable(false);


                        }
                        else //if the passwords do not match give a warning
                        {
                            vPasswordVal.setText("*");
                            validationLabel.setText("Password does not match");
                        }
                    }
                    else
                    {
                        Alert wrongID = new Alert(AlertType.INFORMATION);
                        wrongID.setTitle("Username Error");
                        wrongID.setHeaderText(null);
                        wrongID.setContentText("That name is already taken");

                        wrongID.showAndWait();
                        usernameAddField.clear();
                        usernameAddField.requestFocus();
                    
                    }
                    //close the connections
                    checkRS.close();
                    stmt.close();
                    conn.close();
                    
                }
                catch(SQLException e)
                {
                    e.printStackTrace();
                }
            
        }
    }
    @FXML
    /**
     * Validates the informationPane, makes sure information is correct, then hides pane and opens the next one
     */
    private void handleAdditionalSubmitButton(ActionEvent event)
    {
        
        //Form Validation
        boolean title = FormValidation.choiceBoxNotEmpty(titleChoiceBox, titleVal, "*");
        boolean firstName = FormValidation.textFieldNotEmpty(firstNameAddField, firstNameVal, "*");
        boolean lastName = FormValidation.textFieldNotEmpty(lastNameAddField, lastNameVal, "*");
        boolean gender = FormValidation.choiceBoxNotEmpty(genderChoiceBox, genderVal, "*"); 
        boolean email = FormValidation.textFieldNotEmpty(emailAddField, emailVal, "*");
        boolean location = FormValidation.choiceBoxNotEmpty(locationChoiceBox, locationVal, "*");
        
        if(phoneAddField.getText().matches("^[0-9()]{8}[-]{1}[0-9]{4}"))
        {
        
            if( title && firstName && lastName && gender && email && location)
            {

                //hides the current pane and makes address visible
                informationPane.setDisable(true);
                addressPane.setDisable(false);
            }
        }
        else
        {
            phoneVal.setText("*");
        }
        
        
    }
    @FXML
    /**
     * Validates the addressPane, makes sure information is correct, then hides pane and opens the next one
     */
    private void handleAddressSubmitButton(ActionEvent event)
    {
        //Form Validation
        boolean lineOne = FormValidation.textFieldNotEmpty(lineOneAddField, lineOneVal, "*");
        boolean city = FormValidation.textFieldNotEmpty(cityAddField, cityVal, "*");
        boolean state = FormValidation.comboBoxNotEmpty(stateComboBox, stateVal, "*");
        //zip must be 5 digits exactly
        if(zipAddField.getText().matches("^[0-9]{5}"))
        {
            if(lineOne && city && state)
            {

                addressPane.setDisable(true);
                membershipPane.setDisable(false);

            }
        }
        else
        {
            zipVal.setText("*");
        }
        
        
    }
    
    @FXML
    /**
     * Validates the membershipPane, makes sure information is correct, then hides pane and opens the next one
     */
    private void handleMembershipSubmitButton(ActionEvent event)
    {                
        //Form Validation
        boolean membership = FormValidation.choiceBoxNotEmpty(membershipChoiceBox, membershipVal, "*");
        
        if(membership)
        {
            membershipPane.setDisable(true);
            paymentPane.setDisable(false);
            
        }
        
    }

    @FXML
    /**
     * Validates the paymentPane, makes sure information is correct, then hides pane and opens the next one
     */
    private void handlePaymentSubmitButton(ActionEvent event)
    {   
        //Form Validation
        boolean paymentType = FormValidation.choiceBoxNotEmpty(paymentAddBox, paymentVal, "*");
        boolean cardNumber = FormValidation.textFieldNotEmpty(cardAddField, cardVal, "*");
        boolean expiration = FormValidation.choiceBoxNotEmpty(yearChoiceBox, expirationVal, "*");
        boolean cvv = FormValidation.textFieldNotEmpty(cvvAddField, cvvVal, "*");
        boolean holder = FormValidation.textFieldNotEmpty(holderAddField, holderVal, "*");
        //must be card format
        if(cardAddField.getText().matches("^[0-9]{4}[-]{1}[0-9]{4}[-]{1}[0-9]{4}[-]{1}[0-9]{4}"))
        {
            if(cvvAddField.getText().matches("^[0-9]{3}"))
            {
                if(paymentType && cardNumber && expiration && cvv && holder)
                {
                  addCustomer();   
                }
            }
            else
            {
                cvvVal.setText("*");
            }
        }
        else
        {
            cardVal.setText("*");
        }
        
    }
    /**
     * clears all the data and resets the focus
     */
    private void clearAll()
    {
       //clears the data
           usernameAddField.clear();
           passwordAddField.clear();
           vPasswordAddField.clear();
           titleChoiceBox.setValue(null);
           firstNameAddField.clear();
           lastNameAddField.clear();
           genderChoiceBox.setValue(null);
           phoneAddField.setMask("(___)___-____");
           phoneAddField.setMask("(DDD)DDD-DDDD");
           emailAddField.clear();
           locationChoiceBox.setValue(null);
           lineOneAddField.clear();
           lineTwoAddField.clear();
           cityAddField.clear();
           stateComboBox.setValue(null);
           zipAddField.setMask("_____");
           zipAddField.setMask("DDDDD");
           membershipChoiceBox.setValue(null);
           paymentAddBox.setValue(null);
           cardAddField.setMask("____-____-____-____");
           cardAddField.setMask("DDDD-DDDD-DDDD-DDDD");
           monthChoiceBox.setValue(null);
           yearChoiceBox.setValue(null);
           cvvAddField.setMask("___");
           cvvAddField.setMask("DDD");
           holderAddField.clear();
           emailAddField.setPromptText("");
           usernameAddField.setPromptText("");
           firstNameAddField.setPromptText("");
           lastNameAddField.setPromptText("");
           passwordAddField.setPromptText("");
           vPasswordAddField.setPromptText("");
           lineOneAddField.setPromptText("");
           lineTwoAddField.setPromptText("");
           cityAddField.setPromptText("");
           holderAddField.setPromptText("");                 
           paymentPane.setDisable(true);
           addressPane.setDisable(true);
           informationPane.setDisable(true);
           membershipPane.setDisable(true);            
           accountPane.setDisable(false);
           usernameAddField.requestFocus();  
           usernameVal.setText("");
           passwordVal.setText("");
           vPasswordVal.setText("");
           titleVal.setText("");
           firstNameVal.setText("");
           lastNameVal.setText("");
           genderVal.setText("");
           phoneVal.setText("");
           emailVal.setText("");
           locationVal.setText("");
           lineOneVal.setText("");
           lineTwoVal.setText("");
           cityVal.setText("");
           stateVal.setText("");
           zipVal.setText("");
           cardVal.setText("");
           paymentVal.setText("");
           expirationVal.setText("");
           holderVal.setText("");
           membershipVal.setText(""); 
           
           
    }
    @FXML
    /**
     * Clears any text in the fields when button is pressed
     */
    private void handleClearAddButtonAction(ActionEvent event)
    {
        //checks to make sure you want to clear
        Alert clearCheck = new Alert(AlertType.CONFIRMATION);
        clearCheck.setTitle("Confirm Clear");
        clearCheck.setHeaderText("Are you sure?");
        
        Optional <ButtonType> result = clearCheck.showAndWait();
        
        if (result.get() == ButtonType.OK)
        {        
           clearAll();         
        }
       
       
     
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //initialize choice box options
        paymentAddBox.setItems(FXCollections.observableArrayList("Visa","MasterCard","American Express"));
        membershipChoiceBox.setItems(FXCollections.observableArrayList("Bronze", "Silver", "Gold"));
        titleChoiceBox.setItems(FXCollections.observableArrayList("Mr." , "Ms." , "Mrs.", "Mx."));
        locationChoiceBox.setItems(FXCollections.observableArrayList("Tucson, AZ" , "Los Angeles, CA" , "San Francisco, CA" , "Denver, CO" ,
                                                                     "Chicago, IL" , "Detroit, MI" , "Albuquerque, NM" , "Cincinnati, OH" , "Columbus, OH" ,
                                                                     "Philadelphia, PA" , "Dallas, TX" , "Houston, TX" , "Arlington, VA" , "Milwaukee, WI"));
        monthChoiceBox.setItems(FXCollections.observableArrayList("January", "February", "March" , "April", "May" , "June", "July", "August", "September", "October", "November", "December"));
        genderChoiceBox.setItems(FXCollections.observableArrayList("M", "F", "Other"));
        stateComboBox.setItems(FXCollections.observableArrayList("AK","AL","AR","AZ","CA","CO","CT","DC","DE","FL",
                                                                 "GA","GU","HI","IA","ID", "IL","IN","KS","KY","LA",
                                                                 "MA","MD","ME","MH","MI","MN","MO","MS","MT","NC",
                                                                 "ND","NE","NH","NJ","NM","NV","NY", "OH","OK","OR",
                                                                 "PA","PR","PW","RI","SC","SD","TN","TX","UT","VA",
                                                                 "VI","VT","WA","WI","WV","WY"));
        
        //makes the state combo box autocomplete        
        FxUtilTest.autoCompleteComboBoxPlus(stateComboBox, (typedText, itemToCompare) -> itemToCompare.toString().toUpperCase().startsWith(typedText.toUpperCase()));      
        
        //get the year        
        for(int i = 0; i <=20; i++)
        {
            int year = 2016;
            year = year + i;
            yearChoiceBox.getItems().add(i, year);
        }
        
        //disable panes
        informationPane.setDisable(true);
        addressPane.setDisable(true);
        paymentPane.setDisable(true);
        membershipPane.setDisable(true);
        
        //add action listeners for live validation
        FormValidation.addLiveValidation(usernameAddField, "^[A-Za-z0-9]{0,20}|$", usernameVal, validationLabel,"Username must be alphanumeric\n must be 20 characters or less");
        FormValidation.addLiveValidation(passwordAddField, "(?=[A-Za-z0-9]{6,20})(?=.*[A-Za-z])(?=.*[0-9])[A-Za-z0-9]+|", passwordVal, validationLabel,"Password must be alphanumeric\n must be at least 6 characters\n must contain at least 1 number");      
        FormValidation.addLiveValidation(lineOneAddField, "^[A-Za-z0-9 ]{0,60}|$", lineOneVal, validationLabel,"Address must be alphanumeric\n must be 60 characters or less");
        FormValidation.addLiveValidation(lineTwoAddField, "^[A-Za-z0-9 ]{0,60}|$", lineTwoVal, validationLabel,"Address must be alphanumeric\n must be 60 characters or less");
        FormValidation.addLiveValidation(cityAddField, "^[A-Za-z0-9 ]{0,60}|$", cityVal, validationLabel,"City must be letters only \n must be 30 letters or less");      
        FormValidation.addLiveValidation(emailAddField, "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])|",
                                         emailVal, validationLabel,"Enter a valid E-mail address");         
        FormValidation.addLiveValidation(zipAddField, "^[0-9]{5}|$", zipVal, validationLabel,"Zip must contain 5 digits", "_____", "DDDDD");
        FormValidation.addLiveValidation(firstNameAddField, "^[a-zA-Z]{1,20}|$", firstNameVal, validationLabel,"name must be letters only\n must be 20 letters or less");
        FormValidation.addLiveValidation(lastNameAddField, "^[a-zA-Z]{1,20}|$", lastNameVal, validationLabel,"name must be letters only\n must be 20 letters or less");
        FormValidation.addLiveValidation(holderAddField, "^[a-zA-Z ]{1,35}|$", holderVal, validationLabel,"name must be letter only\n must be 35 characters or less");
        FormValidation.addLiveValidation(phoneAddField, "^[0-9()]{8}[-]{1}[0-9]{4}", phoneVal, validationLabel,"Phone number must be 10 digits", "(___)___-____", "(DDD)DDD-DDDD");
        FormValidation.addLiveValidation(cvvAddField, "^[0-9]{3}", cvvVal, validationLabel,"CVV must be 3 digits", "___", "DDD");
        FormValidation.addLiveValidation(cardAddField, "^[0-9]{4}[-]{1}[0-9]{4}[-]{1}[0-9]{4}[-]{1}[0-9]{4}", cardVal, validationLabel,"Card number must be 10 digits", "____-____-____-____", "DDDD-DDDD-DDDD-DDDD");
        
        
                              
    }
    
    
    /**
     * adds a customer to the database
     * validates information
     */
    private void addCustomer()
    {
        //initialize variables
        int locationID = 0; //determined locationID
        
        
        //initialize queries and their builders
        // builers will create the queries based on the users input
        String accountQuery = "INSERT INTO accounts (account_username, account_password, permission_level) VALUES("; //Holds the beginnings of a search query
        String accountBuilder = "";
        
        String infoQuery = "INSERT INTO customer (account_username, location_ID, title, first_name, last_name, gender, phone, email) VALUES (";
        String infoBuilder = "";
        
        String addressQuery = "INSERT INTO address (address, address2, city, state, zip) VALUES (";
        String addressBuilder = "";
        
        String membershipQuery = "INSERT INTO membership (plan, rate) VALUES (";
        String membershipBuilder = "";
        
        String paymentQuery = "INSERT INTO payment(account_username, location_ID, payment_type, card_number, expiration_date, cvv, card_holder) VALUES (";
        String paymentBuilder = "";
        
        //show alert box to make sure information is correct
        Alert infoCorrect = new Alert(AlertType.CONFIRMATION);
        infoCorrect.setTitle("Confirm Information");
        infoCorrect.setHeaderText("Are you sure?");
        infoCorrect.setContentText("Username: " + usernameAddField.getText() + "\nTitle: " + titleChoiceBox.getValue().toString() +
                                   "\nFirst Name: " + firstNameAddField.getText() +"\nLast Name: " + lastNameAddField.getText() +
                                   "\nGender: " + genderChoiceBox.getValue() + "\nPhone: " + phoneAddField.getText() +
                                   "\nE-mail: " + emailAddField.getText() +
                                   "\n\nAddress: " + lineOneAddField.getText() +
                                   "\n           " + lineTwoAddField.getText() +
                                   "\nCity: " + cityAddField.getText() + "\nState: " + stateComboBox.getValue().toString() +
                                   "\nZip: " + zipAddField.getText() + 
                                   "\n\nMembership Plan: " + membershipChoiceBox.getValue().toString());
        
        Optional<ButtonType> result =  infoCorrect.showAndWait();
        
        //if okay is clicked
        if(result.get() == ButtonType.OK)
        {                   
            //builds account query
            accountBuilder = "'" +usernameAddField.getText() + "', '" + passwordAddField.getText() + "', 1)";
            accountQuery = accountQuery + accountBuilder;
            System.out.println(accountQuery); //test

            //builds additional information query
            //Determine the location ID based on the selected location
                Location custLocation =  new Location(locationChoiceBox.getValue().toString());                
                infoBuilder = "'" + usernameAddField.getText() + "', " + custLocation.determineLocationID() + ", '" + titleChoiceBox.getValue().toString() + "', '" + firstNameAddField.getText() 
                        + "', '" + lastNameAddField.getText() + "', '" + genderChoiceBox.getValue().toString() + "', '" + phoneAddField.getText() + "', '" + emailAddField.getText() + "')"; 

                infoQuery = infoQuery + infoBuilder;
                System.out.println(infoQuery); //test

                //build the address query
                if(lineTwoAddField.getText().isEmpty())
                {
                    addressBuilder = "'" + lineOneAddField.getText() + "', NULL , '" + cityAddField.getText() + "', '"+ stateComboBox.getValue().toString() + "', '" + zipAddField.getText() + "')";        
                }
                else
                {
                    addressBuilder = "'" + lineOneAddField.getText() + "', '" + lineTwoAddField.getText() + "', '" + cityAddField.getText() + "', '"+ stateComboBox.getValue().toString() + "', '" + zipAddField.getText() + "')";        
                }

                addressQuery = addressQuery + addressBuilder;
                System.out.println(addressQuery);

                //build the membership query
                //Determine the cost of each membership
                String plan = membershipChoiceBox.getValue().toString();
                double rate = 0;
                switch(plan) //WILL NEED UPDATED
                {
                    case "Bronze":
                        rate = 9.99;
                        break;
                    case "Silver":
                        rate = 19.99;
                        break;
                    case "Gold":
                        rate = 29.99;
                        break;
                }

                membershipBuilder = "'" + membershipChoiceBox.getValue().toString() + "', " + rate + ")";
                membershipQuery = membershipQuery + membershipBuilder;
                System.out.println(membershipQuery);

                //build the payment query
                //get the card String without the dashes
                String stringWithDashes = cardAddField.getText();
                String stringNoDashes = stringWithDashes.replaceAll("\\D+","");
                //Find out the digit of the month
                Month expMonth = new Month(monthChoiceBox.getValue().toString());
                paymentBuilder = "'" + usernameAddField.getText() + "', " + custLocation.determineLocationID() + ", '" + paymentAddBox.getValue().toString() + "', '" + stringNoDashes + "', '" + yearChoiceBox.getValue().toString() + "-" + expMonth.determineMonthInt() + "-01" + "', '" + cvvAddField.getText() + "', '" + holderAddField.getText() + "')";
                paymentQuery = paymentQuery + paymentBuilder;
                System.out.println("This is the payment query: " + paymentQuery);
                
                
                //connect and perform the sql statements
                try
                {
                    
                    //connect to the database and create statement
                    Connection conn = SqlConnection.DBconnect();
                    java.sql.Statement stmt = conn.createStatement();
                    
                    
                    stmt.executeUpdate(accountQuery);
                    System.out.println("Account successfully added");
                    
                    stmt.executeUpdate(infoQuery);
                    System.out.println("Information added successfully");
                    
                    //insert to address table
                    stmt.executeUpdate(addressQuery, Statement.RETURN_GENERATED_KEYS);
                    System.out.println(addressQuery);
                    ResultSet addressRs = stmt.getGeneratedKeys();
                    if(addressRs.next())
                    {
                        int newAddID = addressRs.getInt(1);
                        System.out.println(newAddID);
                        //Add correct address ID to tables
                        stmt.executeUpdate("Update customer SET address_ID = " + newAddID + " WHERE account_username = '" + usernameAddField.getText() + "'");
                    }
                    System.out.println("Adress successfully added");
                    //insert to membership table
                    stmt.executeUpdate(membershipQuery, Statement.RETURN_GENERATED_KEYS);
                    //if any new keys were auto generated, grab them
                    int newMembID = 0;
                    ResultSet membRs =stmt.getGeneratedKeys();
                    if (membRs.next())
                    {
                        newMembID = membRs.getInt(1);
                        System.out.println(newMembID);
                        //Add correct membership ID to tables
                        stmt.executeUpdate("Update customer SET membership_ID = " + newMembID + " WHERE account_username = '" + usernameAddField.getText() + "'");
                    }
                    System.out.println("Membership info successfully added");
                    
                    
                    //insert into payment table
                    stmt.executeUpdate(paymentQuery, Statement.RETURN_GENERATED_KEYS);
                    ResultSet payRs = stmt.getGeneratedKeys();
                    if(payRs.next())
                    {
                        int newPayID = payRs.getInt(1);
                        System.out.println(newPayID);
                        //Add new payment ID to membership table
                        stmt.executeUpdate("Update membership SET payment_ID = " + newPayID + " WHERE membership_ID = '" + newMembID + "'");
                        
                    }
                    System.out.println("Payment Stuff works");
                    
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Customer was successfully added");

                    alert.showAndWait();
                    
                    //clear out the data so they cannot duplicate it
                    clearAll();
                    //close the connections to the database
                    payRs.close();
                    membRs.close();
                    addressRs.close();
                    stmt.close();
                    conn.close();
                    
                    
                    
                }
                catch(SQLException e)
                {
                  System.out.println("Error adding customer to the database");
                  e.printStackTrace();
                }
        }
        else //if user chose cancel
        {
            
            //set back to the first pane
            paymentPane.setDisable(true);
            addressPane.setDisable(true);
            informationPane.setDisable(true);
            membershipPane.setDisable(true);
            
            
            accountPane.setDisable(false);
        } 
        
    }
    
    
}
