/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager.tabs;

import everhealthmanager.ManagerEmployeeController;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import model.EmpTable;
import model.Location;
import model.SearchedEmployee;
import model.SqlConnection;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class EmployeeSearchTabController implements Initializable 
{
    //holds reference to the Employee Inventory main page
    private ManagerEmployeeController empController;
    
    //Holds the instance of the searched item
    private SearchedEmployee currentEmployee;
    
    //Define Employee Search Table
    @FXML 
    private TableView<EmpTable> empSearchTable;
    @FXML 
    private TableColumn<EmpTable, Integer> iEmployeeID;
    @FXML 
    private TableColumn<EmpTable, String> iLocation;
    @FXML
    private TableColumn<EmpTable, String> iFirstName;
    @FXML
    private TableColumn<EmpTable, String> iLastName;
    
    //Create table data
    final ObservableList<EmpTable> empData = FXCollections.observableArrayList();
    
    //FXML tags
    @FXML private TextField IDSearchField;
    @FXML private TextField firstNameSearchField;
    @FXML private TextField lastNameSearchField;
       
    @FXML private ChoiceBox locationSearchBox;
    
    @FXML
    private void handleClearButton()
    {
        IDSearchField.clear();
        firstNameSearchField.clear();
        lastNameSearchField.clear();
        locationSearchBox.setValue(null);
        IDSearchField.setPromptText("");
        firstNameSearchField.setPromptText("");
        lastNameSearchField.setPromptText("");
        empData.clear();
    }
    @FXML
    private void handleEmployeeSearchButton(ActionEvent event)
    {
        searchEmployees();
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //initialize table cells
        iEmployeeID.setCellValueFactory(new PropertyValueFactory<EmpTable, Integer>("rEmployeeID"));
        iLocation.setCellValueFactory(new PropertyValueFactory<EmpTable, String>("rLocation"));
        iFirstName.setCellValueFactory(new PropertyValueFactory<EmpTable, String>("rFirstName"));
        iLastName.setCellValueFactory(new PropertyValueFactory<EmpTable, String>("rLastName"));
        
        empSearchTable.setItems(empData);
        
        //load items into the location search box
        locationSearchBox.setItems(FXCollections.observableArrayList("Tucson, AZ" , "Los Angeles, CA" , "San Francisco, CA" , "Denver, CO" ,
                                   "Chicago, IL" , "Detroit, MI" , "Albuquerque, NM" , "Cincinnati, OH" , "Columbus, OH" ,
                                   "Philadelphia, PA" , "Dallas, TX" , "Houston, TX" , "Arlington, VA" , "Milwaukee, WI"));
        
        IDSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!IDSearchField.getText().matches("^[0-9]{1,11}|$"))
                       {
                       
                           IDSearchField.setText("");
                           IDSearchField.setPromptText("Enter a Valid Number");
                       }
                       else
                       {
                           IDSearchField.setPromptText("");
                       }
                   }
               });
        firstNameSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!firstNameSearchField.getText().matches("^[a-zA-z]{0,30}$"))
                       {
                       
                           firstNameSearchField.setText("");
                           firstNameSearchField.setPromptText("Enter Valid Letters");
                       }
                       else
                       {
                           firstNameSearchField.setPromptText("");
                       }
                   }
               });
        lastNameSearchField.focusedProperty().addListener((listener, oldVal, newVal) ->
               {
                   if(!newVal)
                   {
                       if(!lastNameSearchField.getText().matches("^[a-zA-z]{0,30}$"))
                       {
                       
                           lastNameSearchField.setText("");
                           lastNameSearchField.setPromptText("Enter Valid Letters");
                       }
                       else
                       {
                           lastNameSearchField.setPromptText("");
                       }
                   }
               });
    }
    
    private void searchEmployees()
    {
        //clear any data in the table currently
        empData.clear();
        
        System.out.println("You clicked the employee search button"); //test
        
        //the rebuildable query based on the selected searchfields
        String employeeQuery = "SELECT * FROM employees WHERE " ;
        
        //Clear any information in the table
        
        //Simplified Validation
        //If all search fields are empty, display an error   
        if(IDSearchField.getText().isEmpty() && locationSearchBox.getValue() == null
           && firstNameSearchField.getText().isEmpty() && lastNameSearchField.getText().isEmpty())
        {
            //show an alert box notifying the user to enter data
            Alert noInput = new Alert(Alert.AlertType.WARNING);
            noInput.setTitle("Warning");
            noInput.setHeaderText(null);
            noInput.setContentText("Please enter data");
            noInput.showAndWait();
        }
        else //perform the action
        {
            System.out.println("Got past the validation");
            
             try
            {
                //Connect to the database
                Connection conn = SqlConnection.DBconnect();                
                java.sql.Statement stmt = conn.createStatement();
                
                //begin logic for appending statements to inventory query
                //if the inventory search field is not empty, add the information to the query
                
                if(!IDSearchField.getText().isEmpty())
                {
                   String IDString = "employee_ID LIKE " + "'" + IDSearchField.getText() + "%'";
                   employeeQuery = employeeQuery + IDString;
                   //checks to add AND statements if any other textfield has data
                   if(locationSearchBox.getValue() != null || !firstNameSearchField.getText().isEmpty() || !lastNameSearchField.getText().isEmpty())
                   {
                      employeeQuery = employeeQuery + " AND ";
                   }
                }
                
                //if the location box isnt emtpy, add the data to the query
                if(locationSearchBox.getValue() != null)
                {
                   //creates a new location object based on the value
                   Location itemLocation = new Location(locationSearchBox.getValue().toString());
                   String locationString = "location_ID = " + "'" + itemLocation.determineLocationID() + "'";
                   employeeQuery = employeeQuery + locationString;
                   //checks to add AND statements if any other textfield has data
                   if(!firstNameSearchField.getText().isEmpty() || !lastNameSearchField.getText().isEmpty())
                   {
                      employeeQuery = employeeQuery + " AND ";
                   }
                   
                }
                //if the first name field isnt empty, add it to the query
                if(!firstNameSearchField.getText().isEmpty())
                {
                   String firstString = "first_name LIKE " + "'" + firstNameSearchField.getText() + "%'";
                   employeeQuery = employeeQuery + firstString;
                   //checks to add AND statements if any other textfield has data
                   if(!lastNameSearchField.getText().isEmpty())
                   {
                      employeeQuery = employeeQuery + " AND ";
                   }
                }
                
                //if last name field isnt empty, add it to the query
                if(!lastNameSearchField.getText().isEmpty())
                {
                   String lastString = "last_name LIKE " + "'" + lastNameSearchField.getText() + "%'";
                   employeeQuery = employeeQuery + lastString;
                   
                }
                
                //test
                System.out.println(employeeQuery);
                
                //process the results into the table
                ResultSet EmpRS = stmt.executeQuery(employeeQuery);
                boolean empty = true; // true if no results are found in the database
                
                while(EmpRS.next())
                {
                    //get the location using the items location ID
                    Location empLocation = new Location(EmpRS.getInt("location_ID"));
                    String place = empLocation.determinePlace();
                    //populate each item as a row in the table
                    EmpTable entry = new EmpTable(EmpRS.getInt("employee_ID"), place , EmpRS.getString("first_name"), EmpRS.getString("last_name"));
                    empData.add(entry);

                   
                
                    empty = false; //false if there is data in the Result Set
                }
                //if there is no data display a message
                if(empty == true)
                {
                    Alert emptyAlert = new Alert(Alert.AlertType.INFORMATION);
                    emptyAlert.setTitle("NO INFORMATION FOUND");
                    emptyAlert.setHeaderText("No employee with that information");
                    emptyAlert.showAndWait();
                }
                EmpRS.close();
                //close the connections
                stmt.close();
                conn.close();
                
            }
            catch(SQLException e)
            {
                System.out.println("Failed to search for employee");
                e.printStackTrace();
            }
                     
        }
    }
    
    @FXML
    private void handleEmployeeRowSelection(MouseEvent event) throws IOException
    {
        if(event.isPrimaryButtonDown() && event.getClickCount() == 2)
        {
            try 
            {               
                //uses the username of the double clicked row to populate a searchedCustomer
                EmpTable empSearch = empSearchTable.getSelectionModel().getSelectedItem();
                System.out.println(empSearch.getREmployeeID());
                
                Connection conn = SqlConnection.DBconnect();
                java.sql.Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("Select * FROM employees WHERE employee_ID = '" + empSearch.getREmployeeID() + "'");
                
                
                while(rs.next())
                {
                   currentEmployee = new SearchedEmployee(rs.getInt("employee_ID"), rs.getString("account_username"), rs.getInt("location_ID"), rs.getString("title"), rs.getString("first_name"), rs.getString("last_name"), rs.getString("birth_date"), rs.getString("gender"), rs.getString("hire_date"), rs.getString("social_security"));
                    //test 
                    System.out.println(currentEmployee.getLastName() + currentEmployee.getBirthDate());
                }
                
                //creates a pop up window with various options
                Alert options = new Alert(Alert.AlertType.CONFIRMATION);
                options.setTitle("EMPLOYEE NAME: " + currentEmployee.getFirstName() +" EMPLOYEE ID: " + currentEmployee.getEmployeeID());
                options.setContentText("Select an option");
                
                ButtonType editButton = new ButtonType("Edit");
                ButtonType deleteButton = new ButtonType("Delete");
                ButtonType cancelButton = new ButtonType ("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                
                options.getButtonTypes().setAll(editButton, deleteButton, cancelButton);
                Optional <ButtonType> result = options.showAndWait();
                
                //opens a new window or closes
                if(result.get() == editButton)
                {
                    empController.setMainEmployee();
                    empController.editEmployee.setDisable(false);
                    empController.searchEmployee.setDisable(true);
                    empController.addEmployee.setDisable(true);
                    empController.employeeTabPane.getSelectionModel().select(empController.editEmployee); 
                    
                    
                }
                if(result.get() == deleteButton)
                {
                   Alert delete = new Alert(Alert.AlertType.CONFIRMATION);
                    delete.setTitle("Employee Name: " + currentEmployee.getFirstName() +" Employee ID: " + currentEmployee.getEmployeeID());
                    delete.setHeaderText("Delete this employee");
                    delete.setContentText("Are you sure you want to delete this employee??"); 
                    Optional<ButtonType> delResult = delete.showAndWait();
                    if (delResult.get() == ButtonType.OK)
                    {
                        stmt.executeUpdate("DELETE FROM employees WHERE employee_ID = '" + currentEmployee.getEmployeeID() + "'");
                        stmt.executeUpdate("DELETE FROM accounts WHERE account_username = '" + currentEmployee.getUserName()+ "'");
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Delete Success");
                        alert.setHeaderText(null);
                        alert.setContentText("Employee successfully removed");

                        alert.showAndWait();
                        
                    } else 
                    {
                        //user chose CANCEL or closed the dialog
                    }
                }
                else
                {
                    //user did not choose an option
                }
                //close the connections
                rs.close();
                stmt.close();
                conn.close();
            }
            catch(SQLException ex)
            {
                System.out.println("Failed to load item information from the database");
                ex.printStackTrace();
            }
        }
    }  
    
    
    public void init(ManagerEmployeeController managerEmployeeController) 
    {
        empController = managerEmployeeController;
    }
    
    
    
    public SearchedEmployee getSearchedEmployee()
    {
        return currentEmployee;
    }
    
}
