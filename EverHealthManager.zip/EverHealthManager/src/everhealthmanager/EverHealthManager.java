/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager;


import model.SqlConnection;
import java.sql.Connection;
import java.util.Optional;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * Prepares and launches the application scene
 * @author Jake
 */
public class EverHealthManager extends Application 
{
   
    Connection conn = null; // holds reference to the database

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.getIcons().add(new Image("/images/everhealth-logo.png"));
        stage.setScene(scene);
        stage.show();
        //find a way to make the red x do something else stage.setOnCloseRequest(event -> {System.);
        checkConnection(); //makes sure database is connected
        
        stage.setOnCloseRequest(event -> 
        {
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Confirm Exit");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to exit?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK)
            {
                //user exits the program
            } 
            else 
            {
                event.consume();
            }
    
        });
    }
	
    /**
     * checks to see if the application successfully connects to the database
     * if not, shows a warning and closes the program
     */
    public void checkConnection()
    {
        conn = SqlConnection.DBconnect();
        if(conn == null)
        {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not connect to the database");
            alert.setContentText("Make sure the database is operational and try again");

            alert.showAndWait();
            System.exit(0);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    
}
