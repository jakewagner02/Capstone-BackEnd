/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager;

import model.SceneChanger;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author Jake
 */
public class EmployeeHomepageController extends SceneChanger implements Initializable {
    
    //fxml injectable fields
    @FXML
    private Label welcomeLabel;
    
    
    @FXML
    /**
     * directs to the customer search page
     */
    
    private void handleCustomerButtonAction(ActionEvent event) throws IOException
    {
        changeScene("EmployeeCustomer.fxml", event);
    }
    
    @FXML
    private void handleEmployeeButtonAction(ActionEvent event) throws IOException
    {
        changeScene("ManagerEmployee.fxml", event);
    }
    
     @FXML
     /**
     * directs to view finances page
     */
    private void handleFinancesButtonAction(ActionEvent event) throws IOException
    {
        changeScene("EmployeeFinances.fxml", event);
    }
    
     @FXML
     /**
      * directs to inventory page
      */
    private void handleInventoryButtonAction(ActionEvent event) throws IOException
    {
        changeScene("EmployeeInventory.fxml", event);
        
    }
    
    @FXML
    /**
     * returns to the login screen
     * @param event 
     */
    private void handleLogoutButtonAction(ActionEvent event) throws IOException 
    {
        changeScene("FXMLDocument.fxml", event);
    }
    

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
    }
    
    public void setWelcomeLabel(String name)
    {
        welcomeLabel.setText("Welcome, " + name + ".");
    }
    
    
    
   
    
}
