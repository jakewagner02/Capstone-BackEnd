/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager;

import everhealthmanager.tabs.EditEmployeeTabController;
import everhealthmanager.tabs.EmployeeSearchTabController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import model.SceneChanger;
import model.SearchedEmployee;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class ManagerEmployeeController extends SceneChanger implements Initializable 
{
    // holds reference to the passed Employee
    SearchedEmployee mainEmployee;
    
    @FXML private EmployeeSearchTabController employeeSearchTabController;
    @FXML private EditEmployeeTabController editEmployeeTabController;
    
    @FXML public Tab editEmployee;
    @FXML public Tab searchEmployee;
    @FXML public Tab addEmployee;
    @FXML public TabPane employeeTabPane;
    
    @FXML
    private void handleReturnButtonAction(ActionEvent event) throws IOException
    {
        changeScene("EmployeeHomepage.fxml", event);
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
       employeeSearchTabController.init(this);
       editEmployeeTabController.init(this);
     
        editEmployee.setDisable(true);
    } 
    
    public void setMainEmployee()
    {
        mainEmployee = employeeSearchTabController.getSearchedEmployee();
        editEmployeeTabController.setEditableEmployee();
    }
    
    public SearchedEmployee getMainEmployee()
    {
        return mainEmployee;
    }
    
}
