/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager;

import everhealthmanager.tabs.AddItemTabController;
import everhealthmanager.tabs.EditItemTabController;
import everhealthmanager.tabs.ItemSearchTabController;
import model.SceneChanger;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import model.SearchedItem;

/**
 * FXML Controller class
 *
 * @author jakew
 */
public class EmployeeInventoryController extends SceneChanger implements Initializable 
{
    //holds the item to be passed
    SearchedItem mainItem;
    
    @FXML private AddItemTabController addItemTabController;
    @FXML private ItemSearchTabController itemSearchTabController;
    @FXML private EditItemTabController editItemTabController;
    
    @FXML public Tab editInventory;
    @FXML public Tab searchInventory;
    @FXML public Tab addInventory;
    @FXML public TabPane inventoryTabPane;
    
    @FXML
    private void handleReturnButtonAction(ActionEvent event) throws IOException
    {
        changeScene("EmployeeHomepage.fxml", event);
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        addItemTabController.init(this);
        itemSearchTabController.init(this);
        editItemTabController.init(this);
     
        editInventory.setDisable(true);
    } 
    
    public void setMainItem()
    {
        mainItem = itemSearchTabController.getSearchedItem();
        editItemTabController.setEditableItem();
    }
    
    public SearchedItem getMainItem()
    {
        return mainItem;
    }
    
}
