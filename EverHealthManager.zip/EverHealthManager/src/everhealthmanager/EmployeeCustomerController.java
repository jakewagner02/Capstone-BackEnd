/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager;

import everhealthmanager.tabs.AddCustomerTabController;
import everhealthmanager.tabs.EditCustomerTabController;
import everhealthmanager.tabs.SearchCustomerTabController;
import model.SceneChanger;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import model.SearchedCustomer;

/**
 * FXML Controller class
 *
 * @author Jacob Wagner
 */
public class EmployeeCustomerController extends SceneChanger implements Initializable 
{
    // holds the currentCustomer
    SearchedCustomer mainCustomer;
    
    //allows access to the add search and edit conrollers
    @FXML private AddCustomerTabController addCustomerTabController;
    @FXML private SearchCustomerTabController searchCustomerTabController;
    @FXML private EditCustomerTabController editCustomerTabController;
    
    @FXML public Tab editCustomer;
    @FXML public Tab searchCustomer;
    @FXML public Tab addCustomer;
    @FXML public TabPane customerTabPane;
    
   
        
    
    
    @FXML
    private void handleReturnButtonAction(ActionEvent event) throws IOException
    {
        changeScene("EmployeeHomepage.fxml", event); //extended from Scenechanger class        
    }
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        searchCustomerTabController.init(this);
        editCustomerTabController.init(this);
     
        editCustomer.setDisable(true);
    }
    
    public void setMainCustomer()
    {
        mainCustomer = searchCustomerTabController.getCustomer();
        editCustomerTabController.setEditableCustomer();
    }
    
    public SearchedCustomer getMainCustomer()
    {
        return mainCustomer;
    }  
    
}
